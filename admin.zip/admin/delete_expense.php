<?php
$id = $_GET['id'];
//Connect DB
//Create query based on the ID passed from you table
//query : delete where Staff_id = $id
// on success delete : redirect the page to original page using header() method
$dbname = "club";
$conn = mysqli_connect("localhost", "root", "", $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// sql to delete a record
//$sql = "DELETE FROM expense WHERE id = $id"; 
$sql = "DELETE FROM expense join activity on expense.activity_Id=activity.activity_Id order by activity.activity_Id WHERE id = $id";

if (mysqli_query($conn, $sql)) {
    mysqli_close($conn);
    header('Location: expense.php'); //If book.php is your main page where you list your all records
    exit;
} else {
  
    echo '<script language="javascript">';
                            echo 'alert("Error deleting record")';
                            echo '</script>';
    echo '<meta http-equiv="refresh" content="0;url=expense.php" />';
   // echo alert("Number enter cannot be negative");
}
?>