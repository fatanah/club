<?php
include "../functions/connect.php";

if($_GET['occasion'])
{
$id=$_GET['occasion'];
 $sql = "UPDATE `tbl_reservation` SET `status`='Cancelled' WHERE occasion='$id'";
 mysql_query( $sql);
	
}
?>