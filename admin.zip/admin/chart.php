<?php 
$DatabaseServer = "localhost";
$DatabaseUsername = "root";
$DatabasePassword = "";
$DatabaseName = "club";

$Connection = mysqli_connect($DatabaseServer, $DatabaseUsername, $DatabasePassword, $DatabaseName);

if ($Connection === false) {
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

//$selectsql = "SELECT * FROM expense JOIN income ON expense.activity_Id=income.activity_Id JOIN total ON expense.activity_Id=total.activity_Id group by expense.activity_Id order by expense.activity_Id";
//$selectsql = mysqli_query($Connection, "SELECT * FROM expense");
//$selectsql2 = mysqli_query($Connection,"SELECT * FROM income");
//$selectsql3 = mysqli_query($Connection,"SELECT * FROM total");

$selectsql= "SELECT activity.activity_name, income.activity_Id, expense.activity_Id, SUM(income.tvalue) AS tvalue,
      SUM(expense.pprice) AS pprice, SUM(income.tvalue) - SUM(expense.pprice) AS total_Income FROM (select activity_Id,sum(tvalue) as tvalue from income group by activity_Id) income
      INNER JOIN (select activity_Id,sum(pprice) as pprice from expense group by activity_Id) expense INNER JOIN (select activity_Id,activity_name from activity group by activity_Id) activity ON income.activity_Id=expense.activity_Id AND expense.activity_Id=activity.activity_Id GROUP BY income.activity_Id,expense.activity_Id, activity.activity_Id";







//$selectsql = "SELECT * FROM graph";
//$selectsql = "SELECT c.total_Income, sum(b.tvalue) AS 'tvalue' , sum(a.pprice) AS 'pprice'
               //from income b, 'expense' a, total c 
              // where a.activity_Id = b.activity_Id 
              // and c.activity_Id = b.activity_Id 
              // group by c.activity_Id 
              // order by c.activity_Id";
               
$result = mysqli_query($Connection, $selectsql);    
?>

<html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['bar']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Activity', 'Income', 'Expenses', 'Total'],

    <?php while($row = mysqli_fetch_array($result)){ ?>
          ['<?php echo $row['activity_name'];?>', 

     <?php echo $row['tvalue'];?>,

    <?php echo $row['pprice'];?>, 
    <?php echo $row['total_Income'];?>] ,
    <?php }  ?>
        ]);

        var options = {
          chart: {
            title: 'Activity Vs Income Expense',
            subtitle: 'Income, Expenses, and Total',
          },
      
        };

        var chart = new google.charts.Bar(document.getElementById('columnchart_material'));

        chart.draw(data, google.charts.Bar.convertOptions(options));
      }
    </script>
  </head>
  <body>
    <div id="columnchart_material" style="width: 800px; height: 500px;"></div>
  </body>
</html>

