<?php include "../functions/templates.php"; 
        headertemplate('Reservation | Administrator'); ?>
  <body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white">

   <?php navbar('reservation'); ?>

     <!-- BEGIN CONTENT -->
            <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <div class="page-content">
                    <!-- BEGIN PAGE HEADER-->
             
                    
                    <!-- BEGIN PAGE TITLE-->
                   <!-- BEGIN PAGE TITLE-->
                          <h3 class="page-title"> Reservation
                        <small>Reservation Details</small>
                    </h3>
                                  <?php
                      require "../functions/connect.php";
                      if(isset($_GET['reg_Id'])){
                         $id = $_GET['reg_Id'];
                      $sql = "select * from tbl_reservation as reservation join tbl_register as register on reservation.reg_Id=register.reg_Id join tbl_user as users on register.reg_Id=users.reg_Id join tbl_main_category as main on reservation.cat_Id=main.cat_Id join tbl_menu as menu on reservation.menu_Id=menu.menu_Id where reservation.reg_Id='$id' group by reservation.reg_Id";
                      $run = mysql_query($sql);

                      while ($row2=mysql_fetch_array($run)) {
                         extract($row2);?>
                 
        <div class="row">
            <div class="col-lg-12">

               <div class="invoice">
                        <div class="row invoice-logo">
                            <div class="col-xs-6 invoice-logo-space">
                                <img src="../images/geancy_logo.png" class="img-responsive" alt="" /> </div>
                            <div class="col-xs-6">
                                <p>
                                  <?php echo date("Y-m-d h:i:sa");?>
                                </p>
                            </div>
                        </div>
                        <hr/>
                        <div class="row">
                            <div class="col-xs-6">
                                <h3>Client:</h3>
                               <label>Full Name: </label>
                                           <input type="hidden" value="<?php echo $reg_Id;?>" name="reg_Id" class="form-control" readonly>
                                        <?php echo ucfirst($fname)." ".ucfirst($lname);

                                        ?>
                                        <br>
                                         <label>Address: </label>
                                         <?php echo ucfirst($address);

                                        ?>
                                          <br>
                                         <label>Contact #: </label>
                                         <?php echo $contact;
                                        ?>
                                          <br>
                                         <label>Email Address: </label>
                                         <?php echo $email;
                                        ?>
                            </div>
                            <div class="col-xs-6">
                                <h3>About:</h3>
                                  <label>Occasion: </label>
                                  <?php echo $occasion;?><br>
                                            <label>Motif: </label>
                                       <?php echo $motif;?><br>
                                         <label>Appointed Date: </label>
                                        <?php echo $appointed_date;?><br>
                                        <label>Appointed Time: </label>
                                     <?php echo $appointed_time;?><br>
                                          <label>Number of Person: </label>
                                       <?php echo $number_person;?><br>
                                          <label>Venue: </label>
                                      <?php echo $venue;?><br>
                                        
                                              <label>Type of Catering: </label>
                                      <?php echo $category_name;?>
                            </div>
                           
                        </div>
                        <div class="row">
                            <div class="col-xs-12">
                               <table class="table table-striped table-bordered table-hover table-checkable order-column">
                                                    <thead>
                                       
                                                      <th>Menu Image</th> 
                                                      <th>Menu Name</th>
                                                      <th>Menu Price</th> 
                                                    </thead>
                                                     <tbody>
                       <?php
                           $sql = mysql_query("select * from tbl_reservation as reservation join tbl_register as register on reservation.reg_Id=register.reg_Id join tbl_user as users on register.reg_Id=users.reg_Id join tbl_main_category as main on reservation.cat_Id=main.cat_Id join tbl_menu as menu on reservation.menu_Id=menu.menu_Id where reservation.reg_Id='$id' ");
                            while ($row3=mysql_fetch_array($sql)) {
                           
                        ?>
                          <td><img class="img-thumbnail" alt="Featured Image" height="100px" width="100px"src="../images/<?php echo $row3['menu_image'];?>"></td>
                        <?php
                            echo "<td>".$row3['menu_name']."</td>";      
                            echo "<td>"."Php. ".number_format($row3['menu_price'],2)."</td>";  
                          
                            echo "</tr>";

                                                   
                                          }
                                     
                         ?>
                                                     </tbody>   
                                                </table>
                            </div>
                        </div>
                        <div class="row">
                            
                            <div class="col-xs-8 invoice-block">
                                 <label>Sub Categories:</label>
                                                 <?php echo $sub_category;?><br>
                                <ul class="list-unstyled amounts">
                                   
                                             
                                    <li>
                                        <strong>Grand Total:</strong> <?php  echo number_format($total_menu_price,2);
                                                  ?> </li>

                                </ul>
                                <br/>
                                <a class="btn btn-lg blue hidden-print margin-bottom-5" onclick="javascript:window.print();"> Print
                                    <i class="fa fa-print"></i>
                                </a>
                               
                            </div>
                        </div>
                    </div>
          <!-- BEGIN SAMPLE FORM PORTLET-->
                           
                        <?php
                          }
                             
                         }
                        ?>
                </div>
                <!-- END CONTENT BODY -->
            </div>
            <!-- END CONTENT -->

              
           <?php footertemplate();?>
</body>