<?php include "../functions/templates.php"; 
        headertemplate('Income | Administrator'); ?>
  <body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white">

   <?php navbar('main_category'); ?>

     <!-- BEGIN CONTENT -->
            <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <div class="page-content">
                    <!-- BEGIN PAGE HEADER-->
             
                      <!-- BEGIN PAGE BAR -->
                   <!-- BEGIN PAGE BAR -->
                    <div class="page-bar">
                        <ul class="page-breadcrumb">
                            <li>
                                <a href="dashboard.php">Home</a>
                                <i class="fa fa-circle"></i>
                            </li>
                            <li>
                                <span>Income</span>
                            </li>
                        </ul>
                        
                    </div>
                    <!-- END PAGE BAR -->
                    <!-- BEGIN PAGE TITLE-->
                    <h3 class="page-title"> Income
                        <small>List of Income</small>
                    </h3>                   <!-- END PAGE TITLE-->
                                  <?php
                      require "../functions/connect.php";
                      if(isset($_GET['id'])){
                         $id = $_GET['id'];
                      $sql = "select * from income where id='$id'";
                      $run = mysql_query($sql);

                      while ($row2=mysql_fetch_array($run)) {
                         extract($row2);?>
                 
        <div class="row">
            <div class="col-lg-6">
          <!-- BEGIN SAMPLE FORM PORTLET-->
                            <div class="portlet light bordered">
                                <div class="portlet-title">
                                    <div class="caption font-red-sunglo">
                                        <i class="icon-settings font-red-sunglo"></i>
                                        <span class="caption-subject bold uppercase"> Edit Income</span>
                                    </div>
                                   
                               
                                            </div>
                                          <label>Income</label>
                                          <input type="text" name="income" class="form-control" value=<?php echo $income;?>>
                                          <label>Activity Name</label>
                                          <select class="form-control select2" name="activity_Id" onchange="showDetails(this.value)">
                                          <option></option>
                                      
                                          <?php
                                           include "../../functions/connect.php";
                                           $cs = mysql_query("SELECT * from activity");

                                           if($cs==true){
                                           while($row=mysql_fetch_assoc($cs)){
                                           extract($row);
                                           echo '<option value='.$activity_Id.'>'.$activity_name.'</option>';
                                           }
                                           }

                                           ?>
                                           </select>
                                           
                              
                                            
                                               <label>Value of Income</label>
                                          <input type="text" name="tvalue" class="form-control" value=<?php echo $tvalue;?>>

                                          <label>Date of Income</label>
                                          <input type="text" name="date" class="form-control" value=<?php echo $date;?>>
                                         
                                    </div>       
                                           
                                          


                                        <hr>
                                        </div>
                                        <div class="form-actions">
                                            <button type="submit" name="edit" class="btn blue">Update</button>
                                            <button type="button" class="btn default">Cancel</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        <?php
                          }
                             extract($_POST);

                if(isset($edit))
                {
                 
                    $sql = "UPDATE `income` SET `income`='$income',`activity_Id`='$activity_Id',`tvalue`='$tvalue', `date`='$date' WHERE `id`='$id'";
                    $run = mysql_query($sql);
                              
                    if($run==true)
                        {
                            echo '<script language="javascript">';
                            echo 'alert("Successfully Updated")';
                            echo '</script>';
                            echo '<meta http-equiv="refresh" content="0;url=menu.php" />';
                        }

                    }
                                            
                         }
                        ?>
                </div>
                <!-- END CONTENT BODY -->
            </div>
            <!-- END CONTENT -->

              
           <?php footertemplate();?>
</body>