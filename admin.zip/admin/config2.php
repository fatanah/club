<?php
	$dbHost = "localhost";
	$dbDatabase = "club";
	$dbPasswrod = "";
	$dbUser = "root";


	$mysqli = mysqli_connect($dbHost, $dbUser, $dbPasswrod, $dbDatabase);
?>