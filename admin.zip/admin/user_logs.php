<?php include "../functions/templates.php"; 
        headertemplate('User Logs Report | Administrator'); ?>
  <body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white">

   <?php navbar('user_logs'); ?>

     <!-- BEGIN CONTENT -->
            <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <div class="page-content">
                    <!-- BEGIN PAGE HEADER-->
             
                    <!-- BEGIN PAGE BAR -->
                    <div class="page-bar">
                        <ul class="page-breadcrumb">
                            <li>
                                <a href="dashboard.php">Home</a>
                                <i class="fa fa-circle"></i>
                            </li>
                            <li>
                                <span>User Logs Report</span>
                            </li>
                        </ul>
                        
                    </div>
                    <!-- END PAGE BAR -->
                    <!-- BEGIN PAGE TITLE-->
                    <h3 class="page-title"> User Logs Report
                        <small>List of User Logs Report</small>
                    </h3>
                     <!-- END PAGE TITLE-->
                             <div class="row">

                        <div class="col-md-12">
                        

                            <!-- BEGIN EXAMPLE TABLE PORTLET-->
                            <div class="portlet light bordered">
                                <div class="portlet-title">
                                    <div class="caption font-dark">
                                        <i class="icon-settings font-dark"></i>
                                        <span class="caption-subject bold uppercase"> List of User Logs Report</span>
                                    </div>
                                   
                                </div>
                                <div class="portlet-body">
                                   
                                    <table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_1">
                                        <thead>
                                           <tr>
                                                <th>User_Id</th>
                                                <th>Username</th>
                                                <th>Time Login</th>
                                                <th>Time Logout</th>
                                                </tr>
                                        </thead>

                                        <tbody>
                                       <?php
                                        include "../functions/connect.php";
                                          $sql = "select * from tbl_user_logs as logs join tbl_user as users on logs.user_Id=users.user_Id ";
                                        $run = mysql_query($sql);

                                        while ($row=mysql_fetch_array($run)) {
                                        extract($row);
                                        $id = $row['log_Id'];
                                        echo '<tr id="rec">';
                 
                                        echo "<td>".$user_Id."</td>";
                                        echo "<td>".$username."</td>";      
                                        echo "<td>".$time_login."</td>"; 
                                        echo "<td>".$time_logout."</td>"; 
                                        echo "</tr>";
                                          }
                                 
                                    

                                        ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <!-- END EXAMPLE TABLE PORTLET-->
                        </div>
                    </div>
                  
                </div>
                <!-- END CONTENT BODY -->
            </div>
            <!-- END CONTENT -->
           
             
           <?php footertemplate();?>

            
</body>