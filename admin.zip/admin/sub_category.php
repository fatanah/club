<?php include "../functions/templates.php"; 
        headertemplate('Sub Categories | Administrator'); ?>
  <body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white">

   <?php navbar('sub_category'); ?>

     <!-- BEGIN CONTENT -->
            <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <div class="page-content">
                    <!-- BEGIN PAGE HEADER-->
             
                    <!-- BEGIN PAGE BAR -->
                    <div class="page-bar">
                        <ul class="page-breadcrumb">
                            <li>
                                <a href="dashboard.php">Home</a>
                                <i class="fa fa-circle"></i>
                            </li>
                            <li>
                                <span>Sub Categories</span>
                            </li>
                        </ul>
                        
                    </div>
                    <!-- END PAGE BAR -->
                    <!-- BEGIN PAGE TITLE-->
                    <h3 class="page-title"> Sub Categories
                        <small>List of Sub Categories</small>
                    </h3>
                     <!-- END PAGE TITLE-->
                             <div class="row">

                        <div class="col-md-12">
                        

                            <!-- BEGIN EXAMPLE TABLE PORTLET-->
                            <div class="portlet light bordered">
                                <div class="portlet-title">
                                    <div class="caption font-dark">
                                        <i class="icon-settings font-dark"></i>
                                        <span class="caption-subject bold uppercase"> List of Sub Categories</span>
                                    </div>
                                   
                                </div>
                                <div class="portlet-body">
                                    <div class="table-toolbar">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="btn-group">
                                                    <button class=" btn sbold green" data-toggle="modal" href="#large"> Add New
                                                        <i class="fa fa-plus"></i>
                                                    </button>
                                                </div>
                                            </div>
                                         
                                        </div>
                                    </div>
                                    <table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_1">
                                        <thead>
                                           <tr>
                                        <th>ID #</th>
                                     
                                        <th>Sub Category</th>
                                        
                                        <th>Action</th>
                                                </tr>
                                        </thead>

                                        <tbody>
                                        <?php
                      include "../functions/connect.php";

                      $sql = "select * from tbl_sub_category as sub join tbl_main_category as main on sub.cat_Id=main.cat_Id";
                      $run = mysql_query($sql);

                      while ($row=mysql_fetch_array($run)) {
                         extract($row);
                          $id = $row['sub_Id'];
                          echo '<tr id="rec">';
                          echo "<td>".$category_name."</td>";
                          echo "<td>".$sub_category."</td>";  
                  
                        
                             
                          echo "<td>".
                          '
                          <a href="edit_sub_category.php?sub_Id='.$id.'"  class=" btn btn-success btn-xs tooltips" title="Click To Edit"><span class="fa fa-trash-o"></span> Edit</a>
                                 '
                           ."</td>";
                          echo "</tr>";
                                          }
                                 
                                     
                         ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <!-- END EXAMPLE TABLE PORTLET-->
                        </div>
                    </div>
                  
                </div>
                <!-- END CONTENT BODY -->
            </div>
            <!-- END CONTENT -->
              <div id="large" class="modal fade bs-modal-lg" tabindex="-1" data-backdrop="static" data-keyboard="false">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                                                    <h4 class="modal-title">Add New</h4>
                                                </div>
                                                <div class="modal-body">
                                                   <form role="form" method="POST" action="add_sub.php">
                                                     <label>Main Category</label>
                                          <select class="form-control select2" name="cat_Id">
                                          <option></option>
                                      
                                          <?php
                                           include "../../functions/connect.php";
                                           $cs = mysql_query("SELECT * from tbl_main_category");

                                           if($cs==true){
                                           while($row=mysql_fetch_assoc($cs)){
                                           extract($row);
                                           echo '<option value='.$cat_Id.'>'.$category_name.'</option>';
                                           }
                                           }

                                           ?>
                                           </select>
                                          <label>Sub Category</label>
                                          <input type="text" name="sub_category" class="form-control tooltips" data-trigger="hover" data-toggle="tooltip" title="" placeholder="Place your title here!" data-original-title="Input Title here" required>
                                          
                                         
                                          
                                            </div>
                                                <div class="modal-footer">
                                                    <button type="button" data-dismiss="modal" class="btn dark btn-outline">Cancel</button>
                                                         <button type="submit" class="btn btn-primary">Submit</button>
                                                </div>
                                                  </div>

                                                </form>
                                            </div>
                                        </div>
                                    </div>



             
           <?php footertemplate();?>

            
</body>