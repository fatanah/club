<?php include "../functions/templates.php"; 
        headertemplate('Reservation Report | Administrator'); ?>
  <body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white">

   <?php navbar('reservation_report'); ?>

     <!-- BEGIN CONTENT -->
            <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <div class="page-content">
                    <!-- BEGIN PAGE HEADER-->
             
                    <!-- BEGIN PAGE BAR -->
                    <div class="page-bar">
                        <ul class="page-breadcrumb">
                            <li>
                                <a href="dashboard.php">Home</a>
                                <i class="fa fa-circle"></i>
                            </li>
                            <li>
                                <span>Reservation Report</span>
                            </li>
                        </ul>
                        
                    </div>
                    <!-- END PAGE BAR -->
                    <!-- BEGIN PAGE TITLE-->
                    <h3 class="page-title"> Reservation Report
                   
                    </h3>
                     <!-- END PAGE TITLE-->
                             <div class="row">

                        <div class="col-md-12">
                        

                            <!-- BEGIN EXAMPLE TABLE PORTLET-->
                            <div class="portlet light bordered">
                                <div class="portlet-title">
                                    <div class="caption font-dark">
                                        <i class="icon-settings font-dark"></i>
                                     
                                    </div>
                                   
                                </div>
                                <div class="portlet-body">
                                    <div class="table-toolbar">
                                            <form method="POST">
                                        <div class="row">
                                            <div class="col-md-4">
                                                  <div class="input-group input-medium date date-picker" data-date-format="dd-mm-yyyy">
                                                                    <input type="text" class="form-control" name="from">
                                                                    <span class="input-group-btn">
                                                                        <button class="btn default" type="button">
                                                                            <i class="fa fa-calendar"></i>
                                                                        </button>
                                                                    </span>
                                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                  <div class="input-group input-medium date date-picker" data-date-format="dd-mm-yyyy" >
                                                                    <input type="text" class="form-control" name="to">
                                                                    <span class="input-group-btn">
                                                                        <button class="btn default" type="button">
                                                                            <i class="fa fa-calendar"></i>
                                                                        </button>
                                                                    </span>
                                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="btn-group">
                                                   <button type="submit" name="generate"class="btn btn-primary">Generate</button>
                                                </div>
                                            </div>
                                         
                                        </div>
                                        </form>
                                    </div>
                                        <?php
                                                extract($_POST);
                                                    if (isset($generate)) {
                                                        
                                                    
                                                ?>
                                                <table class="table table-striped table-bordered table-hover table-checkable order-column">
                                                    <thead>
                                                        <tr>
                                                              <th>Occasion</th>
                                        <th>Appointed Date</th>
                                        <th>Appointed time</th>
                                        <th>Budget</th>
                                        <th>Status</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                    
                                            <?php
                                            
                                            include '../functions/connect.php';
                                              $sql = "select * from tbl_reservation where appointed_date between '$from' and '$to' ";

                                              $run = mysql_query($sql);
                                                $total = 0;
                                              while ($row=mysql_fetch_array($run)) {
                                                 extract($row);
                                                  $id = $row['reservation_Id'];
                                               
                                                  echo '<tr>';
                                            
                                                
                                                    echo "<td>".$occasion."</td>";      
                                                    echo "<td>".$appointed_date."</td>";
                                                    echo "<td>".$appointed_time."</td>";    
                                                    echo "<td>"."Php. ".number_format($budget,2)."</td>";  
                                                    echo "<td>".$status."</td>";    
                                                   echo "</tr>";
                                             
                                                                  }
                                                         
                                                             
                                                 ?>
                                                        
                                                       
                                                    </tbody>
                                                </table>
                                                <?php 
                                                    }
                                                ?>
                               
                                </div>
                            </div>
                            <!-- END EXAMPLE TABLE PORTLET-->
                        </div>
                    </div>
                  
                </div>
                <!-- END CONTENT BODY -->
            </div>
            <!-- END CONTENT -->
             


             
           <?php footertemplate();?>

            
</body>