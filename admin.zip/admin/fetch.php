<?php

//fetch.php

include('config.php');

if(isset($_POST["year"]))
{
 $query = "
 SELECT * FROM income
 WHERE year = '".$_POST["year"]."' 
 ORDER BY id ASC
 ";
 $statement = $connect->prepare($query);
 $statement->execute();
 $result = $statement->fetchAll();
 foreach($result as $row)
 {
  $output[] = array(
   'month'   => $row["month"],
   'tvalue'  => floatval($row["tvalue"])
  );
 }
 echo json_encode($output);
}

?>