<?php


  include "../functions/connect.php";
  include "../functions/templates.php";
  extract($_POST);
	
$sql = mysql_query("insert into income(income,activity_Id,user_Id,tvalue,date) values('$income','$activity_Id','$user_Id','$tvalue','$date')");
$run = mysql_query($sql);
	
	
							if($run==true)
                                  {
                                        echo '<script language="javascript">';
                                        echo 'alert("Successfully Added!")';
                                        echo '</script>';
                                        echo '<meta http-equiv="refresh" content="0;url=income.php" />';
                                  }


												
						

					exit;			


?>

