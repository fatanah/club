<?php
include "../functions/connect.php";

extract($_POST);

$sql = "INSERT INTO `tbl_main_category`(`category_name`) VALUES ('$category_name')";
$run = mysql_query($sql);

  if($run==true)
                                  {
                                        echo '<script language="javascript">';
                                        echo 'alert("Successfully Added!")';
                                        echo '</script>';
                                        echo '<meta http-equiv="refresh" content="0;url=main_category.php" />';
                                  }



?>