<?php
   include "../functions/templates.php"; 
        headertemplate('Expense | Administrator');
	require_once("perpage.php");	
	require_once("dbcontroller2.php");

	$db_handle = new DBController();
	
	$activity_Id = "";
	
	
	$queryCondition = "";
	if(!empty($_POST["search"])) {
		foreach($_POST["search"] as $k=>$v){
			if(!empty($v)) {

				$queryCases = array("activity_Id");
				if(in_array($k,$queryCases)) {
					if(!empty($queryCondition)) {
						$queryCondition .= " AND ";
					} else {
						$queryCondition .= " WHERE ";
					}
				}
				switch($k) {
					case "activity_Id":
						$activity_Id = $v;
						$queryCondition .= "activity_Id LIKE '" . $v . "%'";
						break;
					
				}
			}
		}
	}
	
	
	$sql = "select * from expense join activity on expense.activity_Id=activity.activity_Id join income on expense.activity_Id=income.activity_Id order by activity.activity_Id desc". $queryCondition;

	$href = 'search2.php';					
		
	$perPage = 2; 
	$page = 1;
	if(isset($_POST['page'])){
		$page = $_POST['page'];
	}
	$start = ($page-1)*$perPage;
	if($start < 0) $start = 0;
		
	$query =  $sql .  $orderby . " limit " . $start . "," . $perPage; 
	$result = $db_handle->runQuery($query);
	
	if(!empty($result)) {
		$result["perpage"] = showperpage($sql, $perPage, $href);
	}

?>

	
	<body class ="page-header-fixed page-sidebar-closed-hide-logo page-content-white">
		<link href="style.css" type="text/css" rel="stylesheet" />

   <?php navbar('expense'); ?>

     <!-- BEGIN CONTENT -->
            <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <div class="page-content">
                    <!-- BEGIN PAGE HEADER-->
             
                    <!-- BEGIN PAGE BAR -->
                    <div class="page-bar">
                        <ul class="page-breadcrumb">
                            <li>
                                <a href="dashboard.php">Home</a>
                                <i class="fa fa-circle"></i>
                            </li>
                            <li>
                                <span>Expense Activity</span>
                            </li>
                        </ul>
                        
                    </div>
                    <!-- END PAGE BAR -->
                    <!-- BEGIN PAGE TITLE-->
                    <h3 class="page-title"> I
                        <small>List Of Expense</small>
                    </h3>
                     <!-- END PAGE TITLE-->
                      
                   
                                   
                                
    <div id="toys-grid">      
			<form name="frmSearch" method="post" action="search2.php">
			<div class="search-box">
			<p><input type="text" placeholder="activity_Id" name="search[activity_Id]" class="demoInputBox" value="<?php echo $activity_Id; ?>"		/><input type="submit" name="go" class="btnSearch" value="Search"><input type="reset" class="btnSearch" value="Reset" onclick="window.location='search2.php'"></p>
			</div>
			<br/>
			<br/>

		<center>Expense Table	
			<table cellpadding="10" cellspacing="1">
        <thead>
					<tr>
          <th><strong>Name</strong></th>
          <th><strong>Activity ID</strong></th>          
          <th><strong>Price</strong></th>
					
					
					</tr>
				</thead>
				<tbody>
					<?php
					if(!empty($result)) {
						foreach($result as $k=>$v) {
						  if(is_numeric($k)) {
					?>
          <tr>
					<td><?php echo $result[$k]["pname"]; ?></td>
          <td><?php echo $result[$k]["activity_Id"]; ?></td>
					<td><?php echo $result[$k]["pprice"]; ?></td>
					
					</tr>
					<?php
						  }
					   }
                    }
					if(isset($result["perpage"])) {
					?>
					<tr>
					<td colspan="6" align=right> <?php echo $result["perpage"]; ?></td>
					</tr>
					<?php } ?>
				<tbody>
			</table>
			
			</form>	
		</div>
	</body>
