<?php


  include "../functions/connect.php";
  include "../functions/templates.php";
  extract($_POST);
	
$sql = mysql_query("insert into member(username,password,role,fname,lname,address,contact,email) values('$username','$password','$role','$fname','$lname','$address','$contact','$email')");
$run = mysql_query($sql);
	
	
							if($run==true)
                                  {
                                        echo '<script language="javascript">';
                                        echo 'alert("Successfully Added!")';
                                        echo '</script>';
                                        echo '<meta http-equiv="refresh" content="0;url=income.php" />';
                                  }


												
						

					exit;			


?>

