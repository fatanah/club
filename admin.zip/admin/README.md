## Track  Your Expenses and Income

* Publicly hosted at: https://codefundoiit.000webhostapp.com/
* Demo video at: https://youtu.be/-lsoxJi7Xs4

#### Download and make the following changes in `dbcontroller.php` and `function.php`

```ruby
	private $host = "localhost";
	private $user = "root";
	private $password = "Enter password"; # enter password of your database
	private $database = "Enter Name";     # import `exp_ak.sql` db and enter its name here
	
```

### Sample user name and password
* Username: `sample@gmail.com`
* Password: `12345`

Daily Expense Manager is a  simple but powerful PHP script to manage your expenses with multi-user level and permission.PHP expense manager designed to help individual or business budget, track and possibly control your expenses. It supports tracking of both your expenses and income. This expense management system provides an integrated set of features to help you to manage your expenses and cash flow. It provides the ability to group your income/expenses into categories and lets you set a budget and track expenses in the category.
