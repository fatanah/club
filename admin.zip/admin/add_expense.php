<?php


  include "../functions/connect.php";
  include "../functions/templates.php";
  extract($_POST);
	
$sql = mysql_query("insert into expense(pname,activity_Id,user_Id, pprice,date) values('$pname','$activity_Id','$user_Id','$pprice','$date')");
$run = mysql_query($sql);
	
	
							if($run==true)
                                  {
                                        echo '<script language="javascript">';
                                        echo 'alert("Successfully Added!")';
                                        echo '</script>';
                                        echo '<meta http-equiv="refresh" content="0;url=income.php" />';
                                  }


												
						

					exit;			


?>

