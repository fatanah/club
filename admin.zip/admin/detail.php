 
<?php
include("config.php");
include 'DBController3.php';
$db_handle = new DBController();
$countryResult = $db_handle->runQuery("SELECT DISTINCT activity_Id FROM income ORDER BY activity_Id ASC");?>
<!DOCTYPE html>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        

<?php include "../functions/templates.php"; 
        headertemplate('Reservation | User'); 
        
        ?>

  

   <html>
<head>
    <title>EXcESS MANAGEMENT SYSTEM</title>
    
</head>
<body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white">


   <?php navbar('rating'); ?>

 <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <div class="page-content">
                    <!-- BEGIN PAGE HEADER-->
             
                      <!-- BEGIN PAGE BAR -->
      <!-- BEGIN PAGE BAR -->
                    <div class="page-bar">
                        <ul class="page-breadcrumb">
                            <li>
                                <a href="dashboard.php">Home</a>
                                <i class="fa fa-circle"></i>
                            </li>
                            
 <center><h2><b>Report Income Expense</b></h2><br/>
    <li>    <form method="POST" name="search" action="detail.php">
        <div id="demo-grid">
            <div class="search-box">
                <select id="Place" name="activity_Id[]" multiple="multiple">
                    <option value="0" selected="selected">Select Country</option>
                        <?php
                        if (! empty($countryResult)) {
                            foreach ($countryResult as $key => $value) {
                                echo '<option value="' . $countryResult[$key]['activity_Id'] . '">' . $countryResult[$key]['activity_Id'] . '</option>';
                            }
                        }
                        ?>
                </select><br> <br>
                <button id="Filter">Search</button>
            </div>
            
                <?php
                if (! empty($_POST['activity_Id'])) {
                    ?>
                    <center><h3><b>Table Income</b></h3></center>
                    <table cellpadding="10" cellspacing="1">

                <thead>
                    <tr>
                        <th><strong>Activity ID</strong></th>
                        <th><strong>Name</strong></th>
                        <th><strong>Value</strong></th>
                        <th><strong>Date</strong></th>
                    </tr>
                    
                </thead>
              
                
                <tbody>
                <?php
                $total_price = 0;
                    $query = "SELECT * from income";
                    


                    $i = 0;
                    $selectedOptionCount = count($_POST['activity_Id']);
                    $selectedOption = "";
                    while ($i < $selectedOptionCount) {
                        $selectedOption = $selectedOption . "'" . $_POST['activity_Id'][$i] . "'";
                        if ($i < $selectedOptionCount - 1) {
                            $selectedOption = $selectedOption . ", ";
                        }
                        
                        $i ++;
                    }
                    $query = $query . " WHERE activity_Id in (" . $selectedOption . ")";
                    
                    $result = $db_handle->runQuery($query);
                }
                if (! empty($result)) {
                    foreach ($result as $key => $value) {
                        $total_price += $result[$key]['tvalue'];
                        ?>
                <tr>
                        <td><div class="col" id="user_data_1"><?php echo $result[$key]['activity_Id']; ?></div></td>
                        <td><div class="col" id="user_data_1"><?php echo $result[$key]['income']; ?></div></td>
                        <td><div class="col" id="user_data_2"><?php echo $result[$key]['tvalue']; ?> </div></td>
                        <td><div class="col" id="user_data_3"><?php echo $result[$key]['date']; ?> </div></td>

                    </tr>



                <?php

                    } 
                    ?>
                    
                   <tr><td></td><td></td><td><div class="col" id="user_data_4"><b>Total Price : RM </b><?php echo $total_price; ?> </div></td><td></td><tr>
                  
                </tbody>

            </table>
           

            <br/><br/><br/>
            <center><h3><b>Table Expense</b></h3></center>
           <table cellpadding="10" cellspacing="1">

                <thead>
                    <tr>
                        <th><strong>Activity ID</strong></th>
                        <th><strong>Name</strong></th>
                        <th><strong>Value</strong></th>
                        <th><strong>Date</strong></th>
                    </tr>
                    
                </thead>
              
                
                <tbody>
                <?php
                $total_price = 0;
                    $query = "SELECT * from expense";
                    


                    $i = 0;
                    $selectedOptionCount = count($_POST['activity_Id']);
                    $selectedOption = "";
                    while ($i < $selectedOptionCount) {
                        $selectedOption = $selectedOption . "'" . $_POST['activity_Id'][$i] . "'";
                        if ($i < $selectedOptionCount - 1) {
                            $selectedOption = $selectedOption . ", ";
                        }
                        
                        $i ++;
                    }
                    $query = $query . " WHERE activity_Id in (" . $selectedOption . ")";
                    
                    $result = $db_handle->runQuery($query);
                }
                if (! empty($result)) {
                    foreach ($result as $key => $value) {
                        $total_price += $result[$key]['pprice'];
                        ?>
                <tr>
                        <td><div class="col" id="user_data_1"><?php echo $result[$key]['activity_Id']; ?></div></td>
                        <td><div class="col" id="user_data_1"><?php echo $result[$key]['pname']; ?></div></td>
                        <td><div class="col" id="user_data_2"><?php echo $result[$key]['pprice']; ?> </div></td>
                        <td><div class="col" id="user_data_3"><?php echo $result[$key]['date']; ?> </div></td>

                    </tr>



                <?php

                    } 
                    ?>
                    
                   <tr><td></td><td></td><td><div class="col" id="user_data_4"><b>Total Price : RM </b><?php echo $total_price; ?> </div></td><td></td><tr>
                  
                </tbody>

            </table>
           

            <?php
                }
                ?>  
        </div>
    </form>
</body>
</html>
