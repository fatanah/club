<?php
include "../functions/connect.php";
extract($_POST);

$s = mysql_query("UPDATE `tbl_site_desc` SET `site_title`='$site_title',`site_contact`='$site_contact',`site_email`='$site_email',`site_desc`='$site_desc' WHERE `site_Id`='1'")
                            or die(mysql_error()); 
                if($s==true)
                                  {
                                        echo '<script language="javascript">';
                                        echo 'alert("Successfully Updated")';
                                        echo '</script>';
                                       echo '<meta http-equiv="refresh" content="0;url=page_settings.php" />';
                                  }

?>
