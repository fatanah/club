<?php include "../functions/templates.php"; 
          headertemplate('Main Categories | Administrator'); ?>
  <body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white">

   <?php navbar('main_category'); ?>

     <!-- BEGIN CONTENT -->
            <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <div class="page-content">
                    <!-- BEGIN PAGE HEADER-->
             
                      <!-- BEGIN PAGE BAR -->
                   <div class="page-bar">
                        <ul class="page-breadcrumb">
                            <li>
                                <a href="dashboard.php">Home</a>
                                <i class="fa fa-circle"></i>
                            </li>
                            <li>
                                <span>Main Categories</span>
                            </li>
                        </ul>
                        
                    </div>
                    <!-- END PAGE BAR -->
                    <!-- BEGIN PAGE TITLE-->
                       <h3 class="page-title"> Main Categories
                        <small>List of Main Categories</small>
                    </h3>                    <!-- END PAGE TITLE-->
                                  <?php
                      require "../functions/connect.php";
                      if(isset($_GET['cat_Id'])){
                         $id = $_GET['cat_Id'];
                      $sql = "select * from tbl_main_category where cat_Id='$id'";
                      $run = mysql_query($sql);

                      while ($row2=mysql_fetch_array($run)) {
                         extract($row2);?>
                 
        <div class="row">
            <div class="col-lg-6">
          <!-- BEGIN SAMPLE FORM PORTLET-->
                            <div class="portlet light bordered">
                                <div class="portlet-title">
                                    <div class="caption font-red-sunglo">
                                        <i class="icon-settings font-red-sunglo"></i>
                                        <span class="caption-subject bold uppercase"> Edit Main Category</span>
                                    </div>
                                   
                                </div>
                                <div class="portlet-body form">
                                     <form role="form" method="POST">
                                            <div class="row">
                                                <div class="col-md-12">
                                          <label>Category Name</label>
                                                <input type="text" class="form-control" name="category_name" value="<?php echo $category_name;?>">

                                        </div>

                                        
                                        </div>
                                        <div class="form-actions">
                                            <button type="submit" name="edit" class="btn blue">Update</button>
                                            <button type="button" class="btn default">Cancel</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        <?php
                          }
                             extract($_POST);

                if(isset($edit))
                {
                 
                    $sql = "UPDATE `tbl_main_category` SET `category_name`='$category_name'WHERE `cat_Id`='$id'";
                    $run = mysql_query($sql);
                              
                    if($run==true)
                        {
                            echo '<script language="javascript">';
                            echo 'alert("Successfully Updated")';
                            echo '</script>';
                            echo '<meta http-equiv="refresh" content="0;url=main_category.php" />';
                        }

                    }
                                            
                         }
                        ?>
                </div>
                <!-- END CONTENT BODY -->
            </div>
            <!-- END CONTENT -->

              
           <?php footertemplate();?>
</body>