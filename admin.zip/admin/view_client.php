<?php include "../functions/templates.php"; 
            headertemplate('Client | Administrator'); ?>
  <body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white">

   <?php navbar('client'); ?>

     <!-- BEGIN CONTENT -->
            <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <div class="page-content">
                    <!-- BEGIN PAGE HEADER-->
             
                      <!-- BEGIN PAGE BAR -->
                  <div class="page-bar">
                        <ul class="page-breadcrumb">
                            <li>
                                <a href="dashboard.php">Home</a>
                                <i class="fa fa-circle"></i>
                            </li>
                            <li>
                                <span>Member</span>
                            </li>
                        </ul>
                        
                    </div>
                    <!-- END PAGE BAR -->
                    <!-- BEGIN PAGE TITLE-->
                       <h3 class="page-title"> List Of Member<small></small>
                    </h3>                 <!-- END PAGE TITLE-->
                                  <?php
                      require "../functions/connect.php";
                      if(isset($_GET['user_Id'])){
                         $id = $_GET['user_Id'];
                      $sql = "select * from member  where user_Id='$id'";
                      $run = mysql_query($sql);

                      while ($row2=mysql_fetch_array($run)) {
                         extract($row2);?>
                 
        <div class="row">
            <div class="col-lg-6">
          <!-- BEGIN SAMPLE FORM PORTLET-->
                            <div class="portlet light bordered">
                                <div class="portlet-title">
                                    <div class="caption font-red-sunglo">
                                        <i class="icon-settings font-red-sunglo"></i>
                                        <span class="caption-subject bold uppercase"> View Member</span>
                                    </div>
                                   
                                </div>
                                <div class="portlet-body form">
                                            <div class="row">
                                                <div class="col-md-6">
                                                <label>Full Name: </label>
                                                <?php echo ucfirst($fname)." ".ucfirst($lname);?><br>
                                                <label>Address:</label>
                                                <?php echo $address;?><br>
                                                 <label>Contact #:</label>
                                                <?php echo $contact;?><br>
                                                 <label>Email Address:</label>
                                                <?php echo $email;?><br>
                                            </div>                                        
                                        </div>
                                </div>
                            </div>
                        <?php
                          }
                             
                                            
                         }
                        ?>
                </div>
                <!-- END CONTENT BODY -->
            </div>
            <!-- END CONTENT -->

              
           <?php footertemplate();?>
</body>