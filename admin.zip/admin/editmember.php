<?php include "../functions/templates.php"; 
        headertemplate('Member | Administrator'); ?>
  <body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white">

   <?php navbar('main_category'); ?>

     <!-- BEGIN CONTENT -->
            <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <div class="page-content">
                    <!-- BEGIN PAGE HEADER-->
             
                      <!-- BEGIN PAGE BAR -->
                   <!-- BEGIN PAGE BAR -->
                    <div class="page-bar">
                        <ul class="page-breadcrumb">
                            <li>
                                <a href="dashboard.php">Home</a>
                                <i class="fa fa-circle"></i>
                            </li>
                            <li>
                                <span>Member</span>
                            </li>
                        </ul>
                        
                    </div>
                    <!-- END PAGE BAR -->
                    <!-- BEGIN PAGE TITLE-->
                    <h3 class="page-title"> Member
                        <small>List of Member</small>
                    </h3>                   <!-- END PAGE TITLE-->
                                  <?php
                      require "../functions/connect.php";
                      if(isset($_GET['user_Id'])){
                         $id = $_GET['user_Id'];
                      $sql = "select * from member where user_Id='$id'";
                      $run = mysql_query($sql);

                      while ($row2=mysql_fetch_array($run)) {
                         extract($row2);?>
                 
        <div class="row">
            <div class="col-lg-6">
          <!-- BEGIN SAMPLE FORM PORTLET-->
                            <div class="portlet light bordered">
                                <div class="portlet-title">
                                    <div class="caption font-red-sunglo">
                                        <i class="icon-settings font-red-sunglo"></i>
                                        <span class="caption-subject bold uppercase"> Edit Activity</span>
                                    </div>
                                   
                                </div>
                                <div class="portlet-body form">
                                       <form role="form" method="POST"  enctype="multipart/form-data">
                                                                                  <label>Image</label>
                                    
                                            </div>
                                         <label>Username</label>
                                          <input type="text" name="username" class="form-control" value=<?php echo $username;?>>
                                          
                                          <label>Password</label>
                                           <input type="password" name="password" class="form-control" value=<?php echo $username;?>>
                                               <label>Role</label>
                                          <input type="number" name="role" class="form-control" value=<?php echo $role;?>>
                                          
                                          <label>fname</label>
                                          <input type="text" name="fname" class="form-control" value=<?php echo $fname;?>>
                                          
                                          <label>lname</label>
                                          <input type="text" name="lname" class="form-control" value=<?php echo $lname;?>>
                                          
                                          <label>Address</label>
                                          <input type="address" name="address" class="form-control" value=<?php echo $address;?>>
                                          
                                           <label>Contact</label>
                                          <input type="number" name="contact" class="form-control" value=<?php echo $contact;?>>
                                          
                                          <label>Email</label>
                                          <input type="email" name="email" class="form-control" value=<?php echo $email;?>>
                                          

                                      
                                         

                                        <hr>
                                        </div>
                                        <div class="form-actions">
                                            <button type="submit" name="edit" class="btn blue">Update</button>
                                            <button type="button" class="btn default">Cancel</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        <?php
                          }
                             extract($_POST);

                if(isset($edit))
                {
                 
                    $sql = "UPDATE `member` SET    `username`='$username',`password`='$password',`role`='$role',`fname`='$fname',`lname`='$lname',`address`='$address',`contact`='$contact',`email`='$email' WHERE `user_Id`='$id'";
                    $run = mysql_query($sql);
                              
                    if($run==true)
                        {
                            echo '<script language="javascript">';
                            echo 'alert("Successfully Updated")';
                            echo '</script>';
                            echo '<meta http-equiv="refresh" content="0;url=client.php" />';
                        }

                    }
                                            
                         }
                        ?>
                </div>
                <!-- END CONTENT BODY -->
            </div>
            <!-- END CONTENT -->

              
           <?php footertemplate();?>
</body>