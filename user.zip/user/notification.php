<?php include "../functions/templates.php"; 
        headertemplate('Notification | Administrator'); ?>
  <body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white">

   <?php navbar('notification'); ?>

     <!-- BEGIN CONTENT -->
            <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <div class="page-content">
                    <!-- BEGIN PAGE HEADER-->
             
                    <!-- BEGIN PAGE BAR -->
                    <div class="page-bar">
                        <ul class="page-breadcrumb">
                            <li>
                                <a href="dashboard.php">Home</a>
                                <i class="fa fa-circle"></i>
                            </li>
                            <li>
                                <span>Notification</span>
                            </li>
                        </ul>
                        
                    </div>
                    <!-- END PAGE BAR -->
                    <!-- BEGIN PAGE TITLE-->
                    <h3 class="page-title"> Notification
                        <small>List of Notification</small>
                    </h3>
                     <!-- END PAGE TITLE-->
                             <div class="row">

                        <div class="col-md-12">
                        

                            <!-- BEGIN EXAMPLE TABLE PORTLET-->
                            <div class="portlet light bordered">
                                <div class="portlet-title">
                                    <div class="caption font-dark">
                                        <i class="icon-settings font-dark"></i>
                                        <span class="caption-subject bold uppercase"> List of Notification</span>
                                    </div>
                                   
                                </div>
                                <div class="portlet-body">
                                   
                                    <table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_1">
                                        <thead>
                                           <tr>
                                      
                                        <th>Notification Name</th>
                                        <th>Message</th>
                                        <th>Action</th>
                       
                                                </tr>
                                        </thead>

                                        <tbody>
                                         <?php
                      include "../functions/connect.php";
                        $user_Id = $_SESSION['sess_user_id'];
                      $sql = "select * from tbl_notification as notification join tbl_register as register on notification.reg_Id=register.reg_Id join tbl_user as users on register.reg_Id=users.reg_Id where users.user_Id='$user_Id'";
                      $run = mysql_query($sql);

                      while ($row=mysql_fetch_array($run)) {
                         extract($row);
                          $id = $row['notif_Id'];
                          echo '<tr id="rec">';
                        
                        
                            echo "<td>".$notif_name."</td>";      
                            echo "<td>".$notif_content."</td>";
                            echo "<td>".
                                   '  <a href="#"  notif_Id="'.$row['notif_Id'].'" class="deleteNotif btn btn-danger  btn-xs tooltips" title="Click To Approve" data-trigger="hover" data-toggle="tooltip" ><span class="fa fa-trash"></span> </a>
                                    '
                           ."</td>";
                            echo "</tr>";
                                          }
                                 
                                     
                         ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <!-- END EXAMPLE TABLE PORTLET-->
                        </div>
                    </div>
                  
                </div>
                <!-- END CONTENT BODY -->
            </div>
            <!-- END CONTENT -->
           
             
           <?php footertemplate();?>

            
</body>