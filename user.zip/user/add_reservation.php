<?php
include "../functions/connect.php";

extract($_POST);

if ($total_menu_price > $budget_value) {
   echo '<script language="javascript">';
                                        echo 'alert("Total Menu Price is greater than your budget please adjust.")';
                                        echo '</script>';
                                          echo '<meta http-equiv="refresh" content="0;url=reservation_page.php" />';
}
else {
$i = 0;
 While($i<sizeof($menu_Id))
 {
$sql = "INSERT INTO `tbl_reservation`(`reg_Id`,`occasion`,`motif`,`appointed_date`,`appointed_time`,`number_person`,`venue`,`budget`, `cat_Id`,`menu_Id`,`status`) VALUES ('$reg_Id','$occasion','$motif','$appointed_date','$appointed_time','$number_person','$venue','$budget','$cat_Id','".$menu_Id[$i]."','Pending')";
$run = mysql_query($sql);
$i++;
}
  if($run==true)
                                  {
                                        echo '<script language="javascript">';
                                        echo 'alert("Successfully Added!")';
                                        echo '</script>';
                                        echo '<meta http-equiv="refresh" content="0;url=reservation.php" />';
                                  }


}
?>