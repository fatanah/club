<?php include "../functions/templates.php"; 
        headertemplate('Reservation | Administrator'); ?>
  <body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white">

   <?php navbar('reservation'); ?>

     <!-- BEGIN CONTENT -->
            <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <div class="page-content">
                    <!-- BEGIN PAGE HEADER-->
             
                    <!-- BEGIN PAGE BAR -->
                    <div class="page-bar">
                        <ul class="page-breadcrumb">
                            <li>
                                <a href="dashboard.php">Home</a>
                                <i class="fa fa-circle"></i>
                            </li>
                            <li>
                                <span>Reservation</span>
                            </li>
                        </ul>
                        
                    </div>
                    <!-- END PAGE BAR -->
                    <!-- BEGIN PAGE TITLE-->
                    <h3 class="page-title"> Reservation
                        <small>Reservation Form</small>
                    </h3>
                     <!-- END PAGE TITLE-->
                             <div class="row">

                        <div class="col-md-12">
                        

                            <!-- BEGIN EXAMPLE TABLE PORTLET-->
                            <div class="portlet light bordered">
                                <div class="portlet-title">
                                    <div class="caption font-dark">
                                        <i class="icon-settings font-dark"></i>
                                        <span class="caption-subject bold uppercase"> Fill out the Fields below</span>
                                    </div>
                                   
                                </div>
                                <div class="portlet-body">

                                     <form method="POST" >
                                         <?php
                                             include "../functions/connect.php";
                                            $user_Id = $_SESSION['sess_user_id'];
                                            $sql = "select * from tbl_register as register join tbl_user as users on register.reg_Id=users.reg_Id where role='2' and users.user_Id='$user_Id'";
                                            $run = mysql_query($sql);

                                            while($row=mysql_fetch_array($run)){
                                                 extract($row);
                                                
                                           
                                        ?>  
                                        <label>Full Name: </label>
                                           <input type="hidden" value="<?php echo $reg_Id;?>" name="reg_Id" class="form-control" readonly>
                                        <?php echo ucfirst($fname)." ".ucfirst($lname);

                                        ?>
                                        <br>
                                         <label>Address: </label>
                                         <?php echo ucfirst($address);

                                        ?>
                                          <br>
                                         <label>Contact #: </label>
                                         <?php echo $contact;
                                        ?>
                                          <br>
                                         <label>Email Address: </label>
                                         <?php echo $email;
                                        ?>
                                        <?php
                                            }
                                        ?>
                                        <hr>
                                        <div ng-app="">
                                        <div class="row">
                                            <div class="col-md-4 well">
                                        <label>Occasion</label><br>
                                        <input type="text" class="form-control" name="occasion"><br>
                                            <label>Motif</label><br>
                                        <input type="text" class="form-control" name="motif"><br>
                                         <label>Appointed Date</label><br>
                                        <div class="input-group input-medium date date-picker" data-date-format="dd-mm-yyyy" data-date-start-date="+0d">
                                                                    <input type="text" class="form-control" name="appointed_date"readonly>
                                                                    <span class="input-group-btn">
                                                                        <button class="btn default" type="button">
                                                                            <i class="fa fa-calendar"></i>
                                                                        </button>
                                                                    </span>
                                                                </div><br>
                                        <label>Appointed Time</label><br>
                                        <input type="time" class="form-control" name="appointed_time"><br>
                                          <label>Number of Person</label><br>
                                        <input type="number" class="form-control" name="number_person" > <br>
                                          <label>Venue</label><br>
                                        <input type="text" class="form-control" name="venue"><br> 
                                        <!--
                                              <label>Budget</label><br>
                                        <input type="number" class="form-control" name="budget" ng-model="budget"><br>
                                             -->
                                             <!--
                                              <label>Type of Catering</label><br>
                                       <select class="form-control select2" name="cat_Id">
                                          <option></option>
                                      
                                          <?php
                                           include "../../functions/connect.php";
                                           $cs = mysql_query("SELECT * from tbl_main_category");

                                           if($cs==true){
                                           while($row=mysql_fetch_assoc($cs)){
                                           extract($row);
                                           echo '<option value='.$cat_Id.'>'.$category_name.'</option>';
                                           }
                                           }

                                           ?>
                                           </select>
                                         -->
                                           </div>
                                                <div id="school">
                                           <div class="col-md-8">
                      <!--
                                                <table class="table table-striped table-bordered table-hover table-checkable order-column">
                                                    <thead>
                                                         <th>Choose</th>
                                                      <th>Menu Image</th> 
                                                      <th>Menu Name</th>
                                               
                                                
                                                      <th>Menu Price</th> 
                                                    </thead>
                                                     <tbody>
                        <?php
                      include "../functions/connect.php";

                      $sql = "select * from tbl_menu as menu join tbl_main_category as main on menu.cat_Id=main.cat_Id  order by main.cat_Id";
                      $run = mysql_query($sql);

                      while ($row=mysql_fetch_array($run)) {
                         extract($row);
                          $id = $row['menu_Id'];
                          echo '<tr id="rec">';
                      
                          ?>
                          <td><input type="checkbox" name="menu_Id[]"id="price" value="<?php echo $id;?>" rel="<?php echo $menu_price;?>"></td>
                          <td><img class="img-thumbnail" alt="Featured Image" height="100px" width="100px"src="../images/<?php echo $row['menu_image'];?>"></td><?php
                           
                         
                            echo "<td>".$menu_name."</td>";      
                        
                    
                            echo "<td>"."Php. ".number_format($menu_price,2)."</td>";  
                          
                            echo "</tr>";
                                          }
                                 
                                     
                         ?>
                                                     </tbody>   
                                                </table>
                                       -->
                                        
                                                  <label>Type of Catering</label><br>
                                          <select class="form-control select2" name="cat_Id" onchange="showDetails(this.value)">
                                          <option></option>
                                      
                                          <?php
                                           include "../../functions/connect.php";
                                           $cs = mysql_query("SELECT * from tbl_main_category");

                                           if($cs==true){
                                           while($row=mysql_fetch_assoc($cs)){
                                           extract($row);
                                           echo '<option value='.$cat_Id.'>'.$category_name.'</option>';
                                           }
                                           }

                                           ?>
                                           </select>
                    
                                          <div id="txtHint">
                                </div>
                           <div id="txtMenu">
                                </div>
                           
                                                <!--
                                            <label>Budget: Php. </label>
                                            {{budget}}
                        <input type="hidden" class="form-control" name="budget_value"value="{{budget}}" readonly>
                      -->
                                                                                          <br>
                                            <label>Total Menu Amount: Php.</label>
                                            <span id="output"></span>
                                                 <input type="hidden" class="form-control" name="total_menu_price" id="txtval" readonly>

                                              
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                        <hr>
                                        <button type="submit"name="add"class="btn btn-primary">Reserve</button>
                                </div>
                                   </form>
                                   <br><br>
                                   <!--
                                   <?php
include "../functions/connect.php";

extract($_POST);
if (isset($add)) {
  

if ($total_menu_price > $budget_value) {
   echo '
              <div class="row">
              <div class="col-md-6">
                <div class="alert alert-icon alert-danger" role="alert">
                  <i class="icon wb-close" aria-hidden="true"></i>
                  <p>Total Menu Price is greater than your budget please adjust.</p>
                </div>
                 </div>
              </div>
                ';
 
}
else {
$i = 0;
 While($i<sizeof($menu_Id))
 {
$sql = "INSERT INTO `tbl_reservation`(`reg_Id`,`occasion`,`motif`,`appointed_date`,`appointed_time`,`number_person`,`venue`,`budget`,`cat_Id`,`menu_Id`,`status`) VALUES ('$reg_Id','$occasion','$motif','$appointed_date','$appointed_time','$number_person','$venue','$budget','$cat_Id','".$menu_Id[$i]."','Pending')";
$run = mysql_query($sql);
$i++;
}
  if($run==true)
                                  {
                                        echo '<script language="javascript">';
                                        echo 'alert("Successfully Added!")';
                                        echo '</script>';
                                        echo '<meta http-equiv="refresh" content="0;url=reservation.php" />';
                                  }


}
}

?>
                            
-->
<?php
include "../functions/connect.php";

extract($_POST);
if (isset($add)) {
  

$i = 0;
 While($i<sizeof($menu_Id))
 {
$sql = "INSERT INTO `tbl_reservation`(`reg_Id`,`occasion`,`motif`,`appointed_date`,`appointed_time`,`number_person`,`venue`,`cat_Id`,`menu_Id`,`sub_Id`,`total_menu_price`,`status`) VALUES ('$reg_Id','$occasion','$motif','$appointed_date','$appointed_time','$number_person','$venue','$cat_Id','".$menu_Id[$i]."','$sub_Id','$total_menu_price','Pending')";
$run = mysql_query($sql);
$i++;
}
  if($run==true)
                                  {
                                        echo '<script language="javascript">';
                                        echo 'alert("Successfully Added!")';
                                        echo '</script>';
                                        echo '<meta http-equiv="refresh" content="0;url=reservation.php" />';
                                  }


}


?>

                            </div>
                            <!-- END EXAMPLE TABLE PORTLET-->
                        </div>
                    </div>
                  
                </div>
                <!-- END CONTENT BODY -->
            </div>
            <!-- END CONTENT -->
    
             
           <?php footertemplate();?>

                  <script src="../assets/angular.min.js" type="text/javascript"></script>


</body>