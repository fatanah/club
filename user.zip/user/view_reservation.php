<?php include "../functions/templates.php"; 
        headertemplate('Reservation | User'); ?>
  <body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white">

   <?php navbar('reservation'); ?>

     <!-- BEGIN CONTENT -->
            <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <div class="page-content">
                    <!-- BEGIN PAGE HEADER-->
             
                      <!-- BEGIN PAGE BAR -->
      <!-- BEGIN PAGE BAR -->
                    <div class="page-bar">
                        <ul class="page-breadcrumb">
                            <li>
                                <a href="dashboard.php">Home</a>
                                <i class="fa fa-circle"></i>
                            </li>
                            <li>
                                <span>Reservation</span>
                            </li>
                        </ul>
                        
                    </div>
                    <!-- END PAGE BAR -->
                    <!-- BEGIN PAGE TITLE-->
                   <!-- BEGIN PAGE TITLE-->
                    <h3 class="page-title"> Reservation
                        <small>List of Reservation</small>
                    </h3>
                                  <?php
                      require "../functions/connect.php";
                      if(isset($_GET['reg_Id'])){
                         $id = $_GET['reg_Id'];
                      $sql = "select * from tbl_reservation as reservation join tbl_register as register on reservation.reg_Id=register.reg_Id join tbl_user as users on register.reg_Id=users.reg_Id join tbl_main_category as main on reservation.cat_Id=main.cat_Id join tbl_menu as menu on reservation.menu_Id=menu.menu_Id where reservation.reg_Id='$id' group by reservation.reg_Id";
                      $run = mysql_query($sql);

                      while ($row2=mysql_fetch_array($run)) {
                         extract($row2);?>
                 
        <div class="row">
            <div class="col-lg-12">
          <!-- BEGIN SAMPLE FORM PORTLET-->
                            <div class="portlet light bordered">
                                <div class="portlet-title">
                                    <div class="caption font-red-sunglo">
                                        <i class="icon-settings font-red-sunglo"></i>
                                        <span class="caption-subject bold uppercase">Reservation Information</span>
                                    </div>
                                   
                                </div>
                                   <div class="portlet-body">

                                     <form method="POST" >
                                         <?php
                                             include "../functions/connect.php";
                                            $user_Id = $_SESSION['sess_user_id'];
                                            $sql = "select * from tbl_register as register join tbl_user as users on register.reg_Id=users.reg_Id where role='2' and users.user_Id='$user_Id'";
                                            $run = mysql_query($sql);

                                            while($row=mysql_fetch_array($run)){
                                                 extract($row);
                                                
                                           
                                        ?>  
                                        <label>Full Name: </label>
                                           <input type="hidden" value="<?php echo $reg_Id;?>" name="reg_Id" class="form-control" readonly>
                                        <?php echo ucfirst($fname)." ".ucfirst($lname);

                                        ?>
                                        <br>
                                         <label>Address: </label>
                                         <?php echo ucfirst($address);

                                        ?>
                                          <br>
                                         <label>Contact #: </label>
                                         <?php echo $contact;
                                        ?>
                                          <br>
                                         <label>Email Address: </label>
                                         <?php echo $email;
                                        ?>
                                        <?php
                                            }
                                        ?>
                                        <hr>
                                        <div class="row">
                                            <div class="col-md-4 well">
                                        <label>Occasion</label><br>
                                        <input type="text" class="form-control" name="occasion" value=<?php echo $occasion;?> readonly><br>
                                            <label>Motif</label><br>
                                        <input type="text" class="form-control" name="motif" value=<?php echo $motif;?> readonly><br>
                                         <label>Appointed Date</label><br>
                                        <div class="input-group input-medium date date-picker" data-date-format="dd-mm-yyyy" data-date-start-date="+0d">
                                                                    <input type="text" class="form-control" name="appointed_date"value=<?php echo $appointed_date;?> readonly>
                                                                    <span class="input-group-btn">
                                                                        <button class="btn default" type="button">
                                                                            <i class="fa fa-calendar"></i>
                                                                        </button>
                                                                    </span>
                                                                </div><br>
                                        <label>Appointed Time</label><br>
                                        <input type="time" class="form-control" name="appointed_time" value=<?php echo $appointed_time;?> readonly><br>
                                          <label>Number of Person</label><br>
                                        <input type="number" class="form-control" name="number_person" value=<?php echo $number_person;?> readonly><br>
                                          <label>Venue</label><br>
                                        <input type="text" class="form-control" name="venue" value=<?php echo $venue;?> readonly><br>
                                           
                                            
                                           </div>
                                           <div class="col-md-8">
                                                <table class="table table-striped table-bordered table-hover table-checkable order-column">
                                                    <thead>
                                       
                                                      <th>Menu Image</th> 
                                                      <th>Menu Name</th>
                                                      <th>Menu Price</th> 
                                                    </thead>
                                                     <tbody>
                   
                        
                          <?php
                           $sql = mysql_query("select * from tbl_reservation as reservation join tbl_register as register on reservation.reg_Id=register.reg_Id join tbl_user as users on register.reg_Id=users.reg_Id join tbl_main_category as main on reservation.cat_Id=main.cat_Id join tbl_menu as menu on reservation.menu_Id=menu.menu_Id where reservation.reg_Id='$id' ");
                            while ($row3=mysql_fetch_array($sql)) {
                           
                        ?>
                          <td><img class="img-thumbnail" alt="Featured Image" height="100px" width="100px"src="../images/<?php echo $row3['menu_image'];?>"></td>
                        <?php
                            echo "<td>".$row3['menu_name']."</td>";      
                            echo "<td>"."Php. ".number_format($row3['menu_price'],2)."</td>";  
                          
                            echo "</tr>";
                               
                                          }
                                     
                         ?>
                                                     </tbody>   
                                                </table>
                                                 <label>Type of Catering: </label>
                                                 <?php echo $category_name;?><br>
                                                 <label>Sub Categories:</label>
                                                 <?php echo $sub_category;?><br>
                                                 <label>Total Menu Amount: Php <?php echo number_format($total_menu_price,2)?></label>
                                           </div>
                                        </div>
                                        <hr>
                                      
                                </div>
                                        
                                </div>
                            </div>
                        <?php
                          }
                             
                         }
                        ?>
                </div>
                <!-- END CONTENT BODY -->
            </div>
            <!-- END CONTENT -->

              
           <?php footertemplate();?>
</body>