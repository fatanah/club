
	<?php
  include "../functions/connect.php";
$m = intval($_GET['m']);
$sql = "select * from tbl_menu where sub_Id='".$m."'";
$result = mysql_query($sql);
while($row = mysql_fetch_array($result)) {

    extract($row);
     $id = $row['menu_Id'];
?>

 <table class="table table-striped table-bordered table-hover table-checkable order-column">
                                                    <thead>
                                                         <th>Choose</th>
                                                      <th>Menu Image</th> 
                                                      <th>Menu Name</th>
                                               
                                                
                                                      <th>Menu Price</th> 
                                                    </thead>
                                                     <tbody>
                  
                          <td><input type="checkbox" id="price" name="menu_Id[]" value="<?php echo $id;?>" rel="<?php echo $menu_price;?>"></td>
                          <td><img class="img-thumbnail" alt="Featured Image" height="100px" width="100px"src="../images/<?php echo $row['menu_image'];?>"></td><?php
                           
                         
                            echo "<td>".$menu_name."</td>";      
                        
                    
                            echo "<td>"."Php. ".number_format($menu_price,2)."</td>";  
                          
                            echo "</tr>";
                                          
                                 
                                     
                         ?>
                                                     </tbody>   
                                                </table>




 

<?php
    }
?>
          
