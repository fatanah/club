<?php
include "../functions/connect.php";

if($_GET['notif_Id'])
{
$id=$_GET['notif_Id'];
 $sql = "DELETE FROM `tbl_notification`  WHERE notif_Id='$id'";
 mysql_query( $sql);
}	
?>