<?php
include "../functions/connect.php";

if($_GET['reservation_Id'])
{
$id=$_GET['reservation_Id'];
 $sql = "UPDATE `tbl_reservation` SET `status`='Cancelled' WHERE reservation_Id='$id'";
 mysql_query( $sql);
}	
?>