<?php include "../functions/templates.php"; 
        headertemplate('Client | Advisor'); ?>

      
  <body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white">

   <?php navbar('member'); ?>

     <!-- BEGIN CONTENT -->
            <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <div class="page-content">
                    <!-- BEGIN PAGE HEADER-->
             
                   

                    <div class="row">
                     
                        <div class="col-md-12 col-sm-12">
                            <div class="portlet light ">
                                <div class="portlet-title">
                                    <div class="caption font-red">
                                        <span class="caption-subject bold uppercase">Member</span>
                 
                                    </div>
                                  
                                </div>
                                <div class="portlet-body">
							
                          <table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_1">
                                        <thead>
                                           <tr>
                           
                                        <th>Username</th>
                                        <th>Address</th>
                                        <th>Contact #</th>
                                        <th>Email</th>
                                        
                                                </tr>
                                        </thead>

                                        <tbody>

                                             <?php
                      include "../functions/connect.php";

                      $sql = "select * from member ";
                      $run = mysql_query($sql);

                      while ($row=mysql_fetch_array($run)) {
                         extract($row);
                          $id = $row['user_Id'];
                          echo '<tr id="rec">';
                          echo "<td>".ucfirst($fname)." ".ucfirst($lname)."</td>";  
                          echo "<td>".$address."</td>";    
                          echo "<td>".$contact."</td>";    
                          echo "<td>".$email."</td>";  
                          echo "<td>".
                          '
                         
                                 '
                           ."</td>";
                          echo "</tr>";
                                          }
                                 
                                     
                         ?>
                                                                                
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
              
                
                        </div>
                    </div>
                </div>
                <!-- END CONTENT BODY -->
				
          

             
           <?php footertemplate();?>

          
</body>