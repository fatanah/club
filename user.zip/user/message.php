<?php include "../functions/templates.php"; 
        headertemplate('Message | Advisor'); ?>

      
  <body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white">

   <?php navbar('message'); ?>

     <!-- BEGIN CONTENT -->
            <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <div class="page-content">
                    <!-- BEGIN PAGE HEADER-->
             
                   

                    <div class="row">
                     
                        <div class="col-md-12 col-sm-12">
                            <div class="portlet light ">
                                <div class="portlet-title">
                                    <div class="caption font-red">
                                        <span class="caption-subject bold uppercase">Message</span>
                 
                                    </div>
                                  
                                </div>
                                <div class="portlet-body">
							
                                  <table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_1">
                                        <thead>
                                           <tr>
                                        <th>ID #</th>
                                        <th>Sender Name</th>
                                        <th>Sender Email</th>
                                        <th>Subject</th>
                                        
                                        
                                                </tr>
                                        </thead>

                                        <tbody>
                                           <?php
                      include "../functions/connect.php";

                      $sql = "select * from tbl_message";
                      $run = mysql_query($sql);

                      while ($row=mysql_fetch_array($run)) {
                         extract($row);
                          $id = $row['message_Id'];
                          echo '<tr id="rec">';
                          echo "<td>".$message_Id."</td>";
                          echo "<td>".$sender_name."</td>";  
                          echo "<td>".$sender_email."</td>";    
                          echo "<td>".$subject."</td>";    
                        
                             
                          echo "<td>".
                          '
                         
                                 '
                           ."</td>";
                          echo "</tr>";
                                          }
                                 
                                     
                         ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
              
                
                        </div>
                    </div>
                </div>
                <!-- END CONTENT BODY -->
				
          

             
           <?php footertemplate();?>

          
</body>