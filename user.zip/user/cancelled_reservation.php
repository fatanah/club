<?php include "../functions/templates.php"; 
        headertemplate('Cancelled Reservation | User'); ?>
  <body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white">

   <?php navbar('reservation'); ?>

     <!-- BEGIN CONTENT -->
            <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <div class="page-content">
                    <!-- BEGIN PAGE HEADER-->
             
                    <!-- BEGIN PAGE BAR -->
                    <div class="page-bar">
                        <ul class="page-breadcrumb">
                            <li>
                                <a href="dashboard.php">Home</a>
                                <i class="fa fa-circle"></i>
                            </li>
                            <li>
                                <span>Cancelled Reservation</span>
                            </li>
                        </ul>
                        
                    </div>
                    <!-- END PAGE BAR -->
                    <!-- BEGIN PAGE TITLE-->
                    <h3 class="page-title"> Cancelled Reservation
                        <small>List of Cancelled Reservation</small>
                    </h3>
                     <!-- END PAGE TITLE-->
                     <a href="reservation.php" class="pull-right btn btn-success">Active Reservation Records</a><br><br>
                             <div class="row">

                        <div class="col-md-12">
                        

                            <!-- BEGIN EXAMPLE TABLE PORTLET-->
                            <div class="portlet light bordered">
                                <div class="portlet-title">
                                    <div class="caption font-dark">
                                        <i class="icon-settings font-dark"></i>
                                        <span class="caption-subject bold uppercase"> List of Cancelled Reservation</span>
                                    </div>
                                   
                                </div>
                                <div class="portlet-body">
                                        
                                    <table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_1">
                                        <thead>
                                           <tr>
                            
                                        <th>Occasion</th>
                                        <th>Appointed Date</th>
                                        <th>Appointed time</th>
                                        <th>Budget</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                                </tr>
                                        </thead>

                                        <tbody>
                                         <?php
                      include "../functions/connect.php";
                        $user_Id = $_SESSION['sess_user_id'];
                      $sql = "select * from tbl_reservation as reservation join tbl_register as register on reservation.reg_Id=register.reg_Id join tbl_user as users on register.reg_Id=users.reg_Id join tbl_main_category as main on reservation.cat_Id=main.cat_Id join tbl_menu as menu on reservation.menu_Id=menu.menu_Id where users.user_Id='$user_Id' and reservation.status ='Cancelled' group by reservation.occasion";
                      $run = mysql_query($sql);

                      while ($row=mysql_fetch_array($run)) {
                         extract($row);
                          $id = $row['reservation_Id'];
                          echo '<tr id="rec">';
                        
                        
                            echo "<td>".$occasion."</td>";      
                            echo "<td>".$appointed_date."</td>";
                            echo "<td>".$appointed_time."</td>";    
                            echo "<td>"."Php. ".number_format($budget,2)."</td>";  
                            echo "<td>".$status."</td>";    
                            echo "<td>".
                                   '<a href="view_reservation.php?reservation_Id='.$id.'"  class="edit_emp btn btn-info btn-xs tooltips" title="Click To View"><span class="fa fa-eye"></span> View</a>
                                    <a href="#" reservation_Id="'.$id.'"   class="cancelReservation btn btn-danger btn-xs tooltips" title="Click To Cancel"><span class="fa fa-archive"></span> Cancel</a>
                                    '
                           ."</td>";
                            echo "</tr>";
                                          }
                                 
                                     
                         ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <!-- END EXAMPLE TABLE PORTLET-->
                        </div>
                    </div>
                  
                </div>
                <!-- END CONTENT BODY -->
            </div>
            <!-- END CONTENT -->
           
             
           <?php footertemplate();?>

            
</body>