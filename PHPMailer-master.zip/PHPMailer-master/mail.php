<?php
require 'PHPMailerAutoload.php';
include "../functions/connect.php";
extract($_POST);
$mail = new PHPMailer;

//$mail->SMTPDebug = 3;                               // Enable verbose debug output

//$mail->isSMTP();                                      // Set mailer to use SMTP
$mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
$mail->SMTPAuth = true;                               // Enable SMTP authentication
$mail->Username = 'rgmak12@gmail.com';                 // SMTP username
$mail->Password = 'movespeed1993';                           // SMTP password
$mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
$mail->Port = 465;                                    // TCP port to connect to

$mail->setFrom($sender, 'Mailer');
$mail->addAddress($receiver, $receiver);     // Add a recipient
$mail->addAddress($receiver);               // Name is optional
$mail->addReplyTo($sender, 'Information');
$mail->addCC('cc@example.com');
$mail->addBCC('bcc@example.com');

$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
$mail->isHTML(true);                                  // Set email format to HTML

$mail->Subject = $subject;
$mail->Body    = $body;
$mail->AltBody = $body;

if(!$mail->send()) {
    echo 'Message could not be sent.';
    echo 'Mailer Error: ' . $mail->ErrorInfo;
	$date= date("Y-m-d h:i:sa");
  		mysql_query("INSERT INTO `tbl_sent_email`(`sender`, `receiver`, `subject`, `body`,`date`,`user_Id`,`status`) VALUES('$sender','$receiver','$subject','$body','$date','$user_Id','active')");
		echo '<script language="javascript">';
		echo 'alert("Message Successfully Sent!")';
		echo '</script>';
		echo '<meta http-equiv="refresh" content="0;url=../academic/cabecs/head/email.php" />'; 
} else {
$date= date("Y-m-d h:i:sa");
  		mysql_query("INSERT INTO `tbl_sent_email`(`sender`, `receiver`, `subject`, `body`,`date`,`user_Id`,`status`) VALUES('$sender','$receiver','$subject','$body','$date','$user_Id','active')");
    echo '<script language="javascript">';
		echo 'alert("Message Successfully Sent!")';
		echo '</script>';
		echo '<meta http-equiv="refresh" content="0;url=../academic/cabecs/head/email.php" />';
}
?>