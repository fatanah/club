<?php include "../functions/templates.php"; 
        headertemplate('Dashboard | Administrator'); ?>

      
  <body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white">

   <?php navbar('dashboard'); ?>

     <!-- BEGIN CONTENT -->
            <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <div class="page-content">
                    <!-- BEGIN PAGE HEADER-->
             
                    <!-- BEGIN PAGE BAR -->
                    <div class="page-bar">
                        <ul class="page-breadcrumb">
                            <li>
                                <a href="dashboard.php">Home</a>
                                <i class="fa fa-circle"></i>
                            </li>
                            <li>
                                <span>Dashboard</span>
                            </li>
                        </ul>
                        <div class="page-toolbar">
                            <div id="dashboard-report-range" class="pull-right tooltips btn btn-sm" data-container="body" data-placement="bottom" data-original-title="Change dashboard date range">
                                <i class="icon-calendar"></i>&nbsp;
                                <span class="thin uppercase hidden-xs"></span>&nbsp;
                                <i class="fa fa-angle-down"></i>
                            </div>
                        </div>
                    </div>
                    <!-- END PAGE BAR -->
                    <!-- BEGIN PAGE TITLE-->
                    <h3 class="page-title"> Activity</h3>
                    <!-- END PAGE TITLE-->
                                    <!-- END PAGE HEADER-->
                    <div class="row">
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                            <div class="dashboard-stat2 ">
                                <div class="display">
                                    <div class="number">
                                      <h3 class="font-green-sharp">
                                                      
                                            
                                      </h3>
                                        
                                    </div>
                                    
                                </div>
                                
                            </div>
                        </div>
                        
                    <div class="row">
                     
                        <div class="col-md-12 col-sm-12">
                            <div class="portlet light ">
                                <div class="portlet-title">
                                    <div class="caption font-red">
                                        <span class="caption-subject bold uppercase">List Activity</span>
                 
                                    </div>
                                  
                                </div>
                                <div class="portlet-body">
                       <table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_1">
                                        <thead>
                                           <tr>
                                        <th>Image</th>
                                        <th>Activity Name</th>
                                        <th>Activity Description</th>
                                        <th>Start Date</th>
                                        <th>End Date</th>
                                       
                                          </tr>
                                        </thead>

                                        <tbody>
                                        <?php
                      include "../functions/connect.php";

                      $sql = "select * from activity as activity order by activity.activity_Id desc";
                      $run = mysql_query($sql);

                      while ($row=mysql_fetch_array($run)) {
                         extract($row);
                          $id = $row['activity_Id'];
                          echo '<tr id="rec">';
                        
                          ?>
                          <td><img class="img-thumbnail" alt="Featured Image" height="100px" width="100px"src="../images/<?php echo $row['activity_image'];?>"></td><?php
                           
                         
                            echo "<td>".$activity_name."</td>"; 
							echo "<td>".$activity_description."</td>";      
                            echo "<td>".$startDate."</td>";
							 echo "<td>".$endDate."</td>";  
                           
                            echo "</tr>";
                                          }
                                 
                                     
                         ?>
                                        </tbody>
                                  </table>
                                </div>
                            </div>
                        </div>
                    </div>
              
                
              </div>
                    </div>
                </div>
                <!-- END CONTENT BODY -->
            </div>
            <!-- END CONTENT -->
             <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria hidden="true">
               <div class="modal-dialog">
                  <div class="modal-content">
                     <div class="modal-header">

                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
                        <h4 class="modal-title" id="myModalLabel">View Post</h4>
                     </div>
                     <div class="modal-body">
                        <h4>Title: </h4>
                        <p id="gettitle" class="well"></p><br>
                        <h4>Type</h4>
                        <p id="gettype" class="well"></p>
                        <h4>Date Posted</h4>
                        <p id="getdate" class="well"></p>
                        <h4>Time Posted</h4>
                          <p id="gettime" class="well"></p>
                        <h4>Content: </h4>
                        <p id="getcontent" class="well"></p>
                     
                        </div>
                         <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
               

                  
                   </div>
                     </div>
                  </div>
               </div>


             
           <?php footertemplate();?>

             <script>
    
    function getdata(id){
      var datastring = 'action=getdata&'+'id='+id;
      var url = 'view_post.php';
      $('#myModal').modal({
        keyboard: true,
        backdrop: 'static'
      });
      
      $.ajax({
        type: "POST",
        data: datastring,
        url: url,
        dataType: 'json',
        success:function (data){
          $('#gettitle').html(data.content_title);
          $('#gettype').html(data.content_type);
          $('#getdate').html(data.content_date);
          $('#gettime').html(data.time);
           $('#getcontent').html(data.content_desc);
        }
      });
      console.log(datastring+url);
    }
    </script>
</body>