<?php include "../functions/templates.php"; 
        headertemplate('Activity | Administrator'); ?>
  <body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white">

   <?php navbar('main_category'); ?>

     <!-- BEGIN CONTENT -->
            <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <div class="page-content">
                    <!-- BEGIN PAGE HEADER-->
             
                      <!-- BEGIN PAGE BAR -->
                   <!-- BEGIN PAGE BAR -->
                    <div class="page-bar">
                        <ul class="page-breadcrumb">
                            <li>
                                <a href="dashboard.php">Home</a>
                                <i class="fa fa-circle"></i>
                            </li>
                            <li>
                                <span>Activity</span>
                            </li>
                        </ul>
                        
                    </div>
                    <!-- END PAGE BAR -->
                    <!-- BEGIN PAGE TITLE-->
                    <h3 class="page-title"> Activity
                        <small>List of Activity</small>
                    </h3>                   <!-- END PAGE TITLE-->
                                  <?php
                      require "../functions/connect.php";
                      if(isset($_GET['activity_Id'])){
                         $id = $_GET['activity_Id'];
                      $sql = "select * from activity   where activity_Id='$id' group by activity_name";
                      $run = mysql_query($sql);

                      while ($row2=mysql_fetch_array($run)) {
                         extract($row2);?>
                 
        <div class="row">
            <div class="col-lg-6">
          <!-- BEGIN SAMPLE FORM PORTLET-->
                            <div class="portlet light bordered">
                                <div class="portlet-title">
                                    <div class="caption font-red-sunglo">
                                        <i class="icon-settings font-red-sunglo"></i>
                                        <span class="caption-subject bold uppercase"> Edit Activity</span>
                                    </div>
                                   
                                </div>
                                <div class="portlet-body form">
                                       <form role="form" method="POST"  enctype="multipart/form-data">
                                                                                  <label>Image</label>
                                    <div class="form-group">
            <div class="fileinput fileinput-new" data-provides="fileinput">
                    <div class="fileinput-new thumbnail" style="width: 200px; height: 150px;">
                          <img class="img-thumbnail" alt="Featured Image"src="../images/<?php echo $row2['activity_image'];?>"></div>
                                <div class="fileinput-preview fileinput-exists thumbnail" style="max-width: 200px; max-height: 150px;"> </div>
                                <div>
                                 <span class="btn default btn-file">
                                                    <span class="fileinput-new"> Select image </span>
                                                      <span class="fileinput-exists"> Change </span>
                                                      <input type="file" name="image"> </span>
                                                        <a href="javascript:;" class="btn default fileinput-exists" data-dismiss="fileinput"> Remove </a>
                                                                    </div>
                                                                </div>
                                            </div>
                                          <label>Activity Name</label>
                                          <input type="text" name="activity_name" class="form-control" value=<?php echo $activity_name;?>>
                                       
                                            

                                            <label>Activity Content</label>
                                            <textarea name="activity_description" id="summernote_1">
                                              <?php echo $activity_description;?>
                                            </textarea>
                                               <label>Start Date</label>
                                          <input type="date" name="startDate" class="form-control" value=<?php echo $startDate;?>>
                                          
                                               <label>End Date</label>
                                          <input type="date" name="endDate" class="form-control" value=<?php echo $endDate;?>>


                                        <hr>
                                        </div>
                                        <div class="form-actions">
                                            
                                            <button type="button" class="btn default">Cancel</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        <?php
                          }
                             
                                            
                         }
                        ?>
                </div>
                <!-- END CONTENT BODY -->
            </div>
            <!-- END CONTENT -->

              
           <?php footertemplate();?>
</body>