<?php include "../functions/templates.php"; 
        headertemplate('Activity | Administrator'); ?>
  <body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white">

   <?php navbar('main_category'); ?>

    
                        
                                   <!-- END PAGE TITLE-->
                                  <?php
                      require "connect.php";
                      if(isset($_GET['id'])){
                         $id = $_GET['id'];
                      $sql = "select * from pelajar where id='$id'";
                      $run = mysql_query($sql);

                      while ($row2=mysql_fetch_array($run)) {
                         extract($row2);?>
                 
        <div class="row">
            <div class="col-lg-6">
          <!-- BEGIN SAMPLE FORM PORTLET-->
                            <div class="portlet light bordered">
                                <div class="portlet-title">
                                    <div class="caption font-red-sunglo">
                                        <i class="icon-settings font-red-sunglo"></i>
                                        <span class="caption-subject bold uppercase"> Edit Pelajar</span>
                                    </div>
                                   
                                </div>
                                <div class="portlet-body form">
                                       <form role="form" method="POST"  enctype="multipart/form-data">
                                                                                  <label>Gambar</label>
                                    <div class="form-group">
            <div class="fileinput fileinput-new" data-provides="fileinput">
                    <div class="fileinput-new thumbnail" style="width: 200px; height: 150px;">
                          <img class="img-thumbnail" alt="Featured Image"src="gambar/<?php echo $row2['gambar'];?>"></div>
                                <div class="fileinput-preview fileinput-exists thumbnail" style="max-width: 200px; max-height: 150px;"> </div>
                                <div>
                                 <span class="btn default btn-file">
                                                    <span class="fileinput-new"> Select Gambar </span>
                                                      <span class="fileinput-exists"> Change </span>
                                                      <input type="file" name="gambar"> </span>
                                                        <a href="javascript:;" class="btn default fileinput-exists" data-dismiss="fileinput"> Remove </a>
                                                                    </div>
                                                                </div>
                                            </div>
                                          <label>Nama</label>
                                          <input type="text" name="nama" class="form-control" value=<?php echo $nama;?>>
                                          

                                           
                                           
                                           <label>kelas</label>
                                          <input type="text" name="kelas" class="form-control" value=<?php echo $kelas;?>>
                                            <label>sekolah</label>
                                          <input type="text" name="sekolah" class="form-control" value=<?php echo $sekolah;?>>
                                          
                                                <label>Nama Ibu Bapa</label>
                                          <input type="text" name="namaParent" class="form-control" value=<?php echo $namaParent;?>>

                                           <label>Telefon No</label>
                                          <input type="number" name="telefonNo" class="form-control" value=<?php echo $telefonNo;?>>


                                        <hr>
                                        </div>
                                        <div class="form-actions">
                                            <button type="submit" name="edit" class="btn blue">Update</button>
                                            <button type="button" class="btn default">Cancel</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        <?php
                          }
                             extract($_POST);

                if(isset($edit))
                {
                 
                    $sql = "UPDATE `pelajar` SET `gambar`='$gambar',`nama`='$nama',`kelas`='$kelas',`sekolah`='$sekolah', `namaParent`='$namaParent', `telefonNo`='$telefonNo' WHERE `activity_Id`='$id'";
                    $run = mysql_query($sql);
                              
                    if($run==true)
                        {
                            echo '<script language="javascript">';
                            echo 'alert("Successfully Updated")';
                            echo '</script>';
                            echo '<meta http-equiv="refresh" content="0;url=form.php" />';
                        }

                    }
                                            
                         }
                        ?>
                </div>
                <!-- END CONTENT BODY -->
            </div>
            <!-- END CONTENT -->

              
           <?php footertemplate();?>
</body>