<?php  

//index.php



$koneksi    = mysqli_connect("localhost", "root", "", "club");
$total_Income  = mysqli_query($koneksi, "SELECT total_Income FROM total order by activity_Id asc");
$year       = mysqli_query($koneksi, "SELECT year FROM income group by year order by activity_Id asc");
?>  
<!DOCTYPE html>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        

<?php include "../functions/templates.php"; 
        headertemplate('Reservation | User'); 
        
        ?>

  

   <html>
<head>
  <title>EXcESS MANAGEMENT SYSTEM</title>
    meta charset="utf-8">
    <title>Report Total</title>
    <script src="js/Chart.js"></script>
    <style type="text/css">
            .container {
                width: 70%;
                margin: 30px auto;
            }
    </style>
</head>
<body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white">


   <?php navbar('rating'); ?>

 <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <div class="page-content">
                    <!-- BEGIN PAGE HEADER-->
             
                      <!-- BEGIN PAGE BAR -->
      <!-- BEGIN PAGE BAR -->
                    <div class="page-bar">
                        <ul class="page-breadcrumb">
                            <li>
                                <a href="dashboard.php">Home</a>
                                <i class="fa fa-circle"></i>
                            </li>
                            <li>

                                <span>Reservation</span>
                            </li>
                        </ul><br/><br/> 
                      <center><h3>Total Income VS Year</h3></center><br/><br/>  
                    </div>

        <div class="container">  
           

<div class="container">
        <canvas id="barchart" width="100" height="100"></canvas>
    </div>
<br /><br />
  </body>
</html>


<script  type="text/javascript">
  var ctx = document.getElementById("barchart").getContext("2d");
  var data = {
            labels: [<?php while ($p = mysqli_fetch_array($year)) { echo '"' . $p['year'] . '",';}?>],
            datasets: [
            {
              label: "Total Income Barang",
              data: [<?php while ($p = mysqli_fetch_array($total_Income)) { echo '"' . $p['total_Income'] . '",';}?>],
              backgroundColor: [
                '#29B0D0',
                '#2A516E',
                '#F07124',
                '#CBE0E3',
                '#979193'
              ]
            }
            ]
            };

  var myBarChart = new Chart(ctx, {
            type: 'bar',
            data: data,
            options: {
            legend: {
              display: false
            },
            barValueSpacing: 20,
            scales: {
              yAxes: [{
                  ticks: {
                      min: 0,
                  }
              }],
              xAxes: [{
                          gridLines: {
                              color: "rgba(0, 0, 0, 0)",
                          }
                      }]
              }
          }
        });
</script>

