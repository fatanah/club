<!DOCTYPE html>
<head>
<meta charset="UTF-8">
<title>jquery Tutorial</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
<script>
$(function(){
$("#startDate").datepicker({
numberOfMonths:1,
dateFormat:'yy-mm-d',
onSelect:function(selectdate){
  var dt=new Date(selectdate);
  dt.setDate(dt.getDate()+1)
  $("#endDate").datepicker("option","minDate",dt);
}
});
$("#endDate").datepicker({
numberOfMonths:1,
dateFormat:'yy/mm/d',
onSelect:function(selectdate){
  var dt=new Date(selectdate);
  dt.setDate(dt.getDate()-1)
  $("#startDate").datepicker("option","maxDate",dt);
}
});
});
</script>
</head>
<body>
<center>
<h1>Date</h1>
</hr>
From Date : <input name="startDate" id="startDate" style="text-align:center;">
To Date : <input name="startDate" id="endDate" style="text-align:center;">
</center>
</body>
</html>
