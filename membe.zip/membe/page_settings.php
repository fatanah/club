<?php include "../functions/templates.php"; 
        headertemplate('Settings | Administrator'); ?>
  <body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white">

   <?php navbar('page_settings'); ?>

     <!-- BEGIN CONTENT -->
            <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <div class="page-content">
                    <!-- BEGIN PAGE HEADER-->
             
                    <!-- BEGIN PAGE BAR -->
                    <div class="page-bar">
                        <ul class="page-breadcrumb">
                            <li>
                                <a href="dashboard.php">Home</a>
                                <i class="fa fa-circle"></i>
                            </li>
                            <li>
                                <span>Settings</span>
                            </li>
                        </ul>
                        
                    </div>
                    <!-- END PAGE BAR -->
                    <!-- BEGIN PAGE TITLE-->
                    <h3 class="page-title"> Settings
                        <small>Page Settings</small>
                    </h3>
                     <!-- END PAGE TITLE-->
                             <div class="row">

                        <div class="col-md-12">
                        

                            <!-- BEGIN EXAMPLE TABLE PORTLET-->
                            <div class="portlet light bordered">
                                <div class="portlet-title">
                                    <div class="caption font-dark">
                                        <i class="icon-settings font-dark"></i>
                                        <span class="caption-subject bold uppercase"> Page Settings</span>
                                    </div>
                                   
                                </div>
                                      <div class="portlet-body">
                             <form id="form_validation" class="uk-form-stacked" method="POST" action="update_site.php">
                                <?php 
                include "../functions/connect.php";
                $sql = mysql_query("SELECT * FROM tbl_site_desc");
                while($row = mysql_fetch_array($sql)){
                extract($row);

                ?>
                          

                                <div class="uk-form-row">
                                    <label for="fullname">Site Title</label>
                                    <input type="text" name="site_title" required class="form-control"value=<?php echo $site_title;?>>
                                </div>
                               <div class="uk-form-row">
                                    <label for="fullname">Site Contact</label>
                                    <input type="text" name="site_contact" required class="form-control" value=<?php echo $site_contact;?>>
                                </div>

                                 <div class="uk-form-row">
                                    <label for="fullname">Site Email</label>
                                    <input type="text" name="site_email" required class="form-control" value=<?php echo $site_email;?>>
                                </div>
                                <div class="uk-form-row">
                                    <label for="message">Description</label>
 <textarea id="summernote_1" cols="30" rows="20" name="site_desc">
 <?php echo $site_desc;?>
            </textarea>                                </div>
                                <div class="uk-form-row">
                                    <button type="submit" class="btn btn-primary">Update</button>
                                </div>
                            </form>
                                </div>
                            </div>
                            <!-- END EXAMPLE TABLE PORTLET-->
                        </div>
                    </div>
                <?php };?>
                </div>
                <!-- END CONTENT BODY -->
            </div>
            <!-- END CONTENT -->
            
           <?php footertemplate();?>
</body>