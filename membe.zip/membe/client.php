<?php include "../functions/templates.php"; 
        headertemplate('Client | Administrator'); ?>

      
  <body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white">

   <?php navbar('member'); ?>

     <!-- BEGIN CONTENT -->
            <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <div class="page-content">
                    <!-- BEGIN PAGE HEADER-->
             
                   

                    <div class="row">
                     
                        <div class="col-md-12 col-sm-12">
                            <div class="portlet light ">
                                <div class="portlet-title">
                                    <div class="caption font-red">
                                        <span class="caption-subject bold uppercase">Member</span>
                 
                                    </div>
                                  
                                </div>
                                <div class="portlet-body">
                                <div class="table-toolbar">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="btn-group">
                                                    
                                                </div>
                                                </div>
                                         
                                        </div>
                                    </div>
							
                          <table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_1">
                                        <thead>
                                           <tr>
                           
                                        <th>Username</th>
                                        <th>Address</th>
                                        <th>Contact #</th>
                                        <th>Email</th>
                                        
                                                </tr>
                                        </thead>

                                        <tbody>

                                             <?php
                      include "../functions/connect.php";

                      $sql = "select * from member ";
                      $run = mysql_query($sql);

                      while ($row=mysql_fetch_array($run)) {
                         extract($row);
                          $id = $row['user_Id'];
                          echo '<tr id="rec">';
                          echo "<td>".ucfirst($fname)." ".ucfirst($lname)."</td>";  
                          echo "<td>".$address."</td>";    
                          echo "<td>".$contact."</td>";    
                          echo "<td>".$email."</td>";  
                          
                          '
                          
                                 '
                           ."</td>";
                          echo "</tr>";
                                          }
                                 
                                     
                         ?>
                                                                                
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
              
                
                        </div>
                    </div>
                </div>
                <!-- END CONTENT BODY -->
                </div>
            <!-- END CONTENT -->
              <div id="large" class="modal fade bs-modal-lg" tabindex="-1" data-backdrop="static" data-keyboard="false">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                                                    <h4 class="modal-title">Add New</h4>
                                                </div>
                                                <div class="modal-body">
                                                   <form role="form" method="POST" action="add_member.php" enctype="multipart/form-data">
                                                                                 
                                    <div class="form-group">
            <div class="fileinput fileinput-new" data-provides="fileinput">
                   
                            
                                            </div>
                                          <label>Username</label>
                                          <input type="text" name="username" class="form-control tooltips" data-trigger="hover" data-toggle="tooltip" title="" placeholder="Place your username here!" data-original-title="Input Username here" required>
                                          
                                          <label>Password</label>
                                           <input type="password" name="password" class="form-control tooltips" data-trigger="hover" data-toggle="tooltip" title="" placeholder="Place your password here!" data-original-title="Input Username here" required>

                                           
                                               <label>Role</label>
                                          <input type="number" name="role" class="form-control tooltips" data-trigger="hover" data-toggle="tooltip" title="" placeholder="Place your role here!" data-original-title="Input role here" required>
                                          
                                          <label>fname</label>
                                          <input type="text" name="fname" class="form-control tooltips" data-trigger="hover" data-toggle="tooltip" title="" placeholder="Place your first name here!" data-original-title="Input first name here" required>
                                          
                                          <label>lname</label>
                                          <input type="text" name="lname" class="form-control tooltips" data-trigger="hover" data-toggle="tooltip" title="" placeholder="Place your last name here!" data-original-title="Input last name here" required>
                                          
                                          <label>Address</label>
                                          <input type="address" name="address" class="form-control tooltips" data-trigger="hover" data-toggle="tooltip" title="" placeholder="Place your address here!" data-original-title="Input address here" required>
                                          
                                           <label>Contact</label>
                                          <input type="number" name="contact" class="form-control tooltips" data-trigger="hover" data-toggle="tooltip" title="" placeholder="Place your contact here!" data-original-title="Input contact here" required>
                                          
                                          <label>Email</label>
                                          <input type="email" name="email" class="form-control tooltips" data-trigger="hover" data-toggle="tooltip" title="" placeholder="Place your email here!" data-original-title="Input email here" required>
                                          
                                          

                                        

                                                <div class="modal-footer">
                                                    <button type="button" data-dismiss="modal" class="btn dark btn-outline">Cancel</button>
                                                         <button type="submit" class="btn btn-primary">Submit</button>
                                                </div>
                                                  </div>

                                                </form>
                                            </div>
                                        </div>
                                    </div>

				
          

             
           <?php footertemplate();?>

          
</body>