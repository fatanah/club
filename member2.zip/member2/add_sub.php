<?php
include "../functions/connect.php";

extract($_POST);

$sql = "INSERT INTO `tbl_sub_category`(`sub_category`,`cat_Id`) VALUES ('$sub_category','$cat_Id')";
$run = mysql_query($sql);

  if($run==true)
                                  {
                                        echo '<script language="javascript">';
                                        echo 'alert("Successfully Added!")';
                                        echo '</script>';
                                        echo '<meta http-equiv="refresh" content="0;url=sub_category.php" />';
                                  }



?>