<?php include "../functions/templates.php"; 
        headertemplate('Activity | Administrator');
        $conn = mysql_connect("localhost", "root", "club");
        if(isset($_POST["btn btn-primary"]))
        {
          $SQL = "CALL activity_add('".$_POST["activity_name"]."', '".$_POST["activity_description"]."', '".$_POST["image"]."', '".$_POST["startDate"]."', '".$_POST["endDate"]."')";
          if(mysql_query($conn, $sql))
          {
            header("location:menu.php?inserted=1");
          }
        }
        if(isset($_GET["inserted"]))
        {
          echo '<script>alert("data inserted")</script>';
        }
        ?>
  <body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white">

   <?php navbar('activity'); ?>

     <!-- BEGIN CONTENT -->
            <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <div class="page-content">
                    <!-- BEGIN PAGE HEADER-->
             
                    <!-- BEGIN PAGE BAR -->
                    <div class="page-bar">
                        <ul class="page-breadcrumb">
                            <li>
                                <a href="dashboard.php">Home</a>
                                <i class="fa fa-circle"></i>
                            </li>
                            <li>
                                <span>Activity</span>
                            </li>
                        </ul>
                        
                    </div>
                    <!-- END PAGE BAR -->
                    <!-- BEGIN PAGE TITLE-->
                    <h3 class="page-title"> Activity
                        <small>List of Activity</small>
                    </h3>
                     <!-- END PAGE TITLE-->
                             <div class="row">

                        <div class="col-md-12">
                        

                            <!-- BEGIN EXAMPLE TABLE PORTLET-->
                            <div class="portlet light bordered">
                                <div class="portlet-title">
                                    <div class="caption font-dark">
                                        <i class="icon-settings font-dark"></i>
                                        <span class="caption-subject bold uppercase"> List of Activity</span>
                                    </div>
                                   
                                </div>
                                <div class="portlet-body">
                                    <div class="table-toolbar">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="btn-group">
                                                    <button class=" btn sbold green" data-toggle="modal" href="#large"> Add New
                                                        <i class="fa fa-plus"></i>
                                                    </button>
                                                </div>
                                            </div>
                                         
                                        </div>
                                    </div>
                                    <table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_1">
                                        <thead>
                                           <tr>
                                        <th>Image</th>
                                        <th>Activity Name</th>
                                        <th>Activity Desc</th>
                                        <th>Start Date</th>
                                         <th>End Date</th>
                                        <th>Action</th>
                                                </tr>
                                        </thead>

                                        <tbody>
                                        <?php
                      include "../functions/connect.php";
                     

                      $sql = "select * from activity ";
                       



                      $run = mysql_query($sql);

                      while ($row=mysql_fetch_array($run)) {
                         extract($row);
                          $id = $row['activity_Id'];
                          echo '<tr id="rec">';
                        
                          ?>
                          <td><img class="img-thumbnail" alt="Featured Image" height="100px" width="100px"src="../images/<?php echo $row['activity_image'];?>"></td><?php
                           
                         
                            echo "<td>".$activity_name."</td>";      
                            echo "<td>".$activity_description."</td>";      
                            echo "<td>".$startDate."</td>";  
							              echo "<td>".$endDate."</td>"; 
                            echo "<td>".
                                   '<a href="view_menu.php?activity_Id='.$id.'"  class="edit_emp btn btn-info btn-xs tooltips" title="Click To View"><span class="fa fa-eye"></span> View</a>
                          <a href="edit_menu.php?activity_Id='.$id.'"  class="btn btn-success btn-xs tooltips" title="Click To Edit"><span class="fa fa-edit"></span> Edit</a>
                          <a href="delete.php?activity_Id='.$id.'"  class="btn btn-success
                           btn-xs tooltips" title="Click To Delete"><span class="fa fa-trash-o"></span> Delete</a>
                          


                                 '

                           ."</td>";
                            echo "</tr>";
                                          }
                                 
                                     
                         ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <!-- END EXAMPLE TABLE PORTLET-->
                        </div>
                    </div>
                  
                </div>
                <!-- END CONTENT BODY -->
            </div>
            <!-- END CONTENT -->
              <div id="large" class="modal fade bs-modal-lg" tabindex="-1" data-backdrop="static" data-keyboard="false">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                                                    <h4 class="modal-title">Add New</h4>
                                                </div>
                                                <div class="modal-body">
                                                  <form role="form" method="POST" action="add_menu.php" enctype="multipart/form-data">
                                                                                  <label>Image</label>
                                    <div class="form-group">
            <div class="fileinput fileinput-new" data-provides="fileinput">
                    <div class="fileinput-new thumbnail" style="width: 200px; height: 150px;">
                          <img src="http://www.placehold.it/200x150/EFEFEF/AAAAAA&amp;text=no+image" alt="" /> </div>
                                <div class="fileinput-preview fileinput-exists thumbnail" style="max-width: 200px; max-height: 150px;"> </div>
                                <div>
                                 <span class="btn default btn-file">
                                                    <span class="fileinput-new"> Select image </span>
                                                      <span class="fileinput-exists"> Change </span>
                                                      <input type="file" name="image"> </span>
                                                        <a href="javascript:;" class="btn default fileinput-exists" data-dismiss="fileinput"> Remove </a>
                                                                    </div>
                                                                </div>
                                            </div>
                                          <label>Activity Name</label>
                                          <input type="text" name="activity_name" class="form-control tooltips" data-trigger="hover" data-toggle="tooltip" title="" placeholder="Place your title here!" data-original-title="Input Title here" required>
                                          
                                      
                                        
                                          
                                          <div id="txtHint">
                                </div>
                                            <label>Activity Description</label>
                                            <textarea name="activity_description" id="summernote_1"></textarea>
                                               <label>Start Date</label>
                                          <input type="date" name="startDate" class="form-control tooltips" data-trigger="hover" data-toggle="tooltip" title="" placeholder="Place your activity conten here!" data-original-title="Input Title here" required>
                                          <label>End Date</label>
                                          <input type="date" name="endDate" class="form-control tooltips" data-trigger="hover" data-toggle="tooltip" title="" placeholder="Place your activity conten here!" data-original-title="Input Title here" required>

                                                <div class="modal-footer">
                                                    <button type="button" data-dismiss="modal" class="btn dark btn-outline">Cancel</button>
                                                         <button type="submit" class="btn btn-primary">Submit</button>
                                                </div>
                                                  </div>

                                                </form>
                                            </div>
                                        </div>
                                    </div>



             
           <?php footertemplate();?>

            
</body>