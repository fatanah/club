<?php include "../functions/templates.php"; 
        headertemplate('Income Activity | Administrator'); ?>
  <body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white">

   <?php navbar('income'); 
   ?>


     <!-- BEGIN CONTENT -->
            <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <div class="page-content">
                    <!-- BEGIN PAGE HEADER-->
             
                    <!-- BEGIN PAGE BAR -->
                    <div class="page-bar">
                        <ul class="page-breadcrumb">
                            <li>
                                <a href="dashboard.php">Home</a>
                                <i class="fa fa-circle"></i>
                            </li>
                            <li>
                                <span>View Income Activity</span>
                            </li>
                        </ul>
                        
                    </div>
                    <!-- END PAGE BAR -->
                    <!-- BEGIN PAGE TITLE-->
                    <h3 class="page-title"> I
                        <small>View List Of Income </small>
                    </h3>
                    
                     <!-- END PAGE TITLE-->
                             <div class="row">

                        <div class="col-md-12">
                        

                            <!-- BEGIN EXAMPLE TABLE PORTLET-->
                            <div class="portlet light bordered">
                                <div class="portlet-title">
                                    <div class="caption font-dark">
                                        <i class="icon-settings font-dark"></i>
                                        <span class="caption-subject bold uppercase">View List Of Income </span>
                                    </div>
                                   
                                </div>
                                <div class="portlet-body">
                                    <div class="table-toolbar">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="btn-group">
                                                    
                                                </div>
                                            </div>
                                         
                                        </div>
                                    </div>
                                    <table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_1">
                                      

                                   
                                        <thead>
                                           <tr>
                                        
                                        <th>Income Name</th>
                                        <th>Activity Name</th>
                                        <th>Value of Income</th>
                                        <th>Date Of Income</th>
                                        
                                                </tr>
                                        </thead>

                                        <tbody>
                                        <?php
                      include "../functions/connect.php";

                      $sql = "select * from income join activity on income.activity_Id=activity.activity_Id order by activity.activity_Id";
                      $run = mysql_query($sql);

                      while ($row=mysql_fetch_array($run)) {
                         extract($row);
                          $id = $row['id'];
                          echo '<tr id="rec">';
                        
                          ?>
                          <?php
                           
                         
                            echo "<td>".$income."</td>";
                            echo "<td>".$activity_name."</td>";        
                            echo "<td>"."RM ".number_format($tvalue,2)."</td>";
                            echo "<td>".$date."</td>";  
                            
                                   '
								   
                          
                                 '
                           ."</td>";
                            echo "</tr>";
                                          }

                                 
                                     
                         ?>

                                        </tbody>

                                    </table>
                                </div>
                            </div>
                            <!-- END EXAMPLE TABLE PORTLET-->
                        </div>
                    </div>
                  
                </div>
                <!-- END CONTENT BODY -->
            </div>
            <!-- END CONTENT -->
              <div id="large" class="modal fade bs-modal-lg" tabindex="-1" data-backdrop="static" data-keyboard="false">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    
           <?php footertemplate();?>

            
</body>