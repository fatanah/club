<?php include "../functions/templates.php"; 
        headertemplate('Expense | Administrator'); ?>
  <body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white">

   <?php navbar('expense'); ?>

     <!-- BEGIN CONTENT -->
            <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <div class="page-content">
                    <!-- BEGIN PAGE HEADER-->
             
                    <!-- BEGIN PAGE BAR -->
                    <div class="page-bar">
                        <ul class="page-breadcrumb">
                            <li>
                                <a href="dashboard.php">Home</a>
                                <i class="fa fa-circle"></i>
                            </li>
                            <li>
                                <span>View Expense Activity</span>
                            </li>
                        </ul>
                        
                    </div>
                    <!-- END PAGE BAR -->
                    <!-- BEGIN PAGE TITLE-->
                    <h3 class="page-title"> I
                        <small>List Of Expense</small>
                    </h3>
                     <!-- END PAGE TITLE-->
                             <div class="row">

                        <div class="col-md-12">
                        

                            <!-- BEGIN EXAMPLE TABLE PORTLET-->
                            <div class="portlet light bordered">
                                <div class="portlet-title">
                                    <div class="caption font-dark">
                                        <i class="icon-settings font-dark"></i>
                                        <span class="caption-subject bold uppercase">View List Of Expense </span>
                                    </div>
                                   
                                </div>
                                <div class="portlet-body">
                                    <div class="table-toolbar">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="btn-group">
                                                   
                                                </div>
                                            </div>
                                         
                                        </div>
                                    </div>
                                    <table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_1">
                                    
                                        <thead>
                                           <tr>
                                        
                                        <th>Expense Name</th>
                                        <th>Activity Name</th>
                                        <th>Value of Expense</th>
                                        <th>Date Of Expense</th>
                                        
                                                </tr>
                                        </thead>

                                        <tbody>
                                        <?php
                      include "../functions/connect.php";

                      $sql = "select * from expense join activity on expense.activity_Id=activity.activity_Id order by activity.activity_Id";
                      $run = mysql_query($sql);

                      while ($row=mysql_fetch_array($run)) {
                         extract($row);
                          $id = $row['id'];
                          echo '<tr id="rec">';
                        

                          ?>
                          <?php
                           
                         
                            echo "<td>".$pname."</td>";
                            echo "<td>".$activity_name."</td>";        
                            echo "<td>"."RM ".number_format($pprice,2)."</td>";
                            echo "<td>".$date."</td>";  
                            
                                   '
								   
                          
                                 '
                           ."</td>";
                            echo "</tr>";
                                          }
                                 
                                     
                         ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <!-- END EXAMPLE TABLE PORTLET-->
                        </div>
                    </div>
                  
                </div>
                <!-- END CONTENT BODY -->
            </div>
            <!-- END CONTENT -->
              <div id="large" class="modal fade bs-modal-lg" tabindex="-1" data-backdrop="static" data-keyboard="false">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                                                    <h4 class="modal-title">Add New</h4>
                                                </div>
                                                <div class="modal-body">
                                                   <form role="form" method="POST" action="add_expense.php" enctype="multipart/form-data">
                                                                                 
                                    <div class="form-group">
            <div class="fileinput fileinput-new" data-provides="fileinput">
                   
                            
                                            </div>
                                          <label>Expense Name</label>
                                          <input type="text" name="pname" class="form-control tooltips" data-trigger="hover" data-toggle="tooltip" title="" placeholder="Place your type here!" data-original-title="Input Type here" required>
                                          
                                          <label>Activity ID</label>
                                          <select class="form-control select2" name="activity_Id" onChange="showDetails(this.value)">
                                          <option></option>
                                      
                                          <?php
                                           include "../../functions/connect.php";
                                           $cs = mysql_query("SELECT * from activity");

                                           if($cs==true){
                                           while($row=mysql_fetch_assoc($cs)){
                                           extract($row);
                                           echo '<option value='.$activity_Id.'>'.$activity_name.'</option>';
                                           }
                                           }

                                           ?>
                                           </select>

                                           
                                   
                                               <label>Expense Value</label>
                                          <input type="number" name="pprice" class="form-control tooltips" data-trigger="hover" data-toggle="tooltip" title="" placeholder="Place your title here!" data-original-title="Input Value here" required>
                                          
                                          <label>Date of Expense</label>
                                          <input type="date" name="date" class="form-control tooltips" data-trigger="hover" data-toggle="tooltip" title="" placeholder="Place your title here!" data-original-title="Input Date here" required>
                                          
                                          

                                        

                                                <div class="modal-footer">
                                                    <button type="button" data-dismiss="modal" class="btn dark btn-outline">Cancel</button>
                                                         <button type="submit" class="btn btn-primary">Submit</button>
                                                </div>
                                                  </div>

                                                </form>
                                            </div>
                                        </div>
                                    </div>



             
           <?php footertemplate();?>

            
</body>