<?php


  include "../functions/connect.php";
  include "../functions/templates.php";
	$path = "../images/";

	$valid_formats = array("jpg", "png", "gif", "bmp");
	if(isset($_POST) and $_SERVER['REQUEST_METHOD'] == "POST")
		{
			$name = $_FILES['image']['name'];
			$size = $_FILES['image']['size'];
		extract($_POST);

			if(strlen($name))
				{
					list($txt, $ext) = explode(".", $name);
					if(in_array($ext,$valid_formats))
					{
					if($size<(1024*1024))
						{
							$image = time().substr(str_replace(" ", "_", $txt), 5).".".$ext;
							$tmp = $_FILES['image']['tmp_name'];
							if(move_uploaded_file($tmp, $path.$image))
								{
//$run1= mysql_query("insert into activity(activity_name,activity_description,activity_image,date) values('$activity_name','$activity_description','$image','$startDate', '$endDate')");
$run1 = mysql_query("call activity_add (NULL,'$activity_name', '$activity_description', '$image', '$startDate','$endDate')");
	
	
							if($run1==true)
								 {
								    echo '<script language="javascript">';
								    echo 'alert("Successfully Added")';
								    echo '</script>';
								    echo '<meta http-equiv="refresh" content="0;url=menu.php" />';
								 }
												
						

								}
							else
							echo "failed";
						}
						else
						echo '<script>alert("Image file size must not exceed 1MB!"); </script>';					
						}
						else
						echo '<script>alert("Invalid file format!"); </script>';	
				}
				
			else
				echo '<script>alert("Please select image to upload"); </script>';
				
			exit;
		}



?>