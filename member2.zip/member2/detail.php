<!DOCTYPE html>
<html>
    <head>
        <link href="//datatables.net/download/build/nightly/jquery.dataTables.css" rel="stylesheet" type="text/css" />

        <script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
        <script src="//datatables.net/download/build/nightly/jquery.dataTables.js"></script>
        <script>

$(document).ready(function() {
    $('#sample_1').DataTable( {
        "footerCallback": function ( row, data, start, end, display ) {
            var api = this.api(), data;
 
            // Remove the formatting to get integer data for summation
            var intVal = function ( i ) {
                return typeof i === 'string' ?
                    i.replace(/[\$,]/g, '')*1 :
                    typeof i === 'number' ?
                        i : 0;
            };
 
            // Total over all pages
            total = api
                .column( 3 )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 );
 
            // Total over this page
            pageTotal = api
                .column( 3, { page: 'current'} )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 );
 
            // Update footer
            $( api.column( 3 ).footer() ).html(
                '$'+pageTotal 
            );
        }
    } );
} );


$(document).ready(function() {
    $('#sample_2').DataTable( {
        "footerCallback": function ( row, data, start, end, display ) {
            var api = this.api(), data;
 
            // Remove the formatting to get integer data for summation
            var intVal = function ( i ) {
                return typeof i === 'string' ?
                    i.replace(/[\$,]/g, '')*1 :
                    typeof i === 'number' ?
                        i : 0;
            };
 
            // Total over all pages
            total = api
                .column( 3 )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 );
 
            // Total over this page
            pageTotal = api
                .column( 3, { page: 'current'} )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 );
 
            // Update footer
            $( api.column( 3 ).footer() ).html(
                '$'+pageTotal 
            );
        }
    } );
} );
</script>
        <meta charset=utf-8 />
        <title>DataTables - JS Bin</title>
    </head>
    <?php include "../functions/templates.php"; 
        headertemplate('Income Activity | Administrator'); ?>
  <body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white">

   <?php navbar('income'); 
   ?>


     <!-- BEGIN CONTENT -->
            <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <div class="page-content">
                    <!-- BEGIN PAGE HEADER-->
             
                    <!-- BEGIN PAGE BAR -->
                    <div class="page-bar">
                        <ul class="page-breadcrumb">
                            <li>
                                <a href="dashboard.php">Home</a>
                                <i class="fa fa-circle"></i>
                            </li>
                            <li>
                                <span>Report Income & Expense</span>
                            </li>
                        </ul>
                        
                    </div>
                    <!-- END PAGE BAR -->
                    <!-- BEGIN PAGE TITLE-->
                    <h3 class="page-title"> I
                        <small>Report Income & Expense </small>
                    </h3>
                    
                     <!-- END PAGE TITLE-->
                             <div class="row">

                        <div class="col-md-12">
                        

                            <!-- BEGIN EXAMPLE TABLE PORTLET-->
                            <div class="portlet light bordered">
                                <div class="portlet-title">
                                    <div class="caption font-dark">
                                        <i class="icon-settings font-dark"></i>
                                        <span class="caption-subject bold uppercase"> Report Income & Expense </span>
                                    </div>
                                   
                                </div>
                                <div class="portlet-body">
                                    <div class="table-toolbar">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="btn-group">
                                                    
                                                </div>
                                            </div>
                                         
                                        </div>
                                    </div>
                                    

                                      
<body>

<table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_1">
                                   
        <thead>
            <tr>
                <th>Income name</th>
                <th>Activity name</th>
                <th>Date Of Income</th>
                <th>Value of Income</th>
                
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>activtity</td>
                <td>Electrorace fkekk</td>
                <td>2019-04-07</td>
                <td>$ 300.00</td>
            </tr>
            <tr>
                <td>activty</td>
                <td>Electra Sublimation Tee</td>
                <td>2019-05-07</td>
                <td>$ 33.00</td>
            </tr>
            <tr>
                <td>club activity</td>
                <td>Survey</td>
                <td>2019-09-15</td>
                <td>$ 45.00</td>
                
            </tr>
            <tr>
                <td>club money</td>
                <td>c++ Workshop</td>
                <td>2019-06-08</td>
                <td>$ 200.00</td>
            </tr>
            <tr>
                <td>Pocket Money</td>
                <td>Leadership</td>
                <td>2018-06-10</td>
                <td>$ 1,000.00</td>
            </tr>
            <tr>
                <td>Sponsor</td>
                <td>Pencarian</td>
                <td>2018-03-10</td>
                <td>$ 5,000.00</td>
                
            </tr>
            <tr>
                <td>sponsor</td>
                <td>Leadership</td>
                <td>2019-10-03</td>
                <td>$ 40.00</td>
            </tr>
            <tr>
                <td>Sponsor</td>
                <td>Survey</td>
                <td>2019-02-10</td>
                <td>$ 1,000.00</td>
            </tr>
            <tr>
                <td>sponsor</td>
                <td>Komplot</td>
                <td>2019-05-07</td>
                <td>$ 900.00</td>
            </tr>
            <tr>
                <td>Club Activity</td>
                <td>Fkekk Fest</td>
                <td>2017-09-03</td>
                <td>$ 400.00</td>
            </tr>
            <tr>
                <td>Sponsor</td>
                <td>Fkekk Fest</td>
                <td>2017-10-10</td>
                <td>$ 700</td>
            </tr>
            <tr>
                <td>Pocket Money</td>
                <td>Fkekk Fest</td>
                <td>2017-10-02</td>
                <td>$ 200</td>
            </tr>
            <tr>
                <td>Sponsor</td>
                <td>Electrorace Fkekk</td>
                <td>2017-11-15</td>
                <td>$ 1000</td>
           
            </tr>
            <tr>
                <td>Sponsor</td>
                <td>Electrorace Fkekk</td>
                <td>2017-12-15</td>
                <td>$ 200</td>
           
            </tr>
            <tr>
                <td>Pocket Money</td>
                <td>c++ Workshop</td>
                <td>2018-08-01</td>
                <td>$ 150</td>
            </tr>
            
        </tbody>
        <tfoot>
            <tr>
                <th colspan="3" style="text-align:right">Total:</th>
                <th></th>
            </tr>
        </tfoot>
    </table>

<table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_2">
                                   
        <thead>
            <tr>
                <th>Expense name</th>
                <th>Activity name</th>
                <th>Date Of Expense</th>
                <th>Value of Expense</th>
                
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Booking tents</td>
                <td>Survey</td>
                <td>2019-06-10</td>
                <td>$ 150.00</td>
            </tr>
            <tr>
                <td>drink</td>
                <td>Electra Sublimation Tee</td>
                <td>2019-05-09</td>
                <td>$ 33.00</td>
            </tr>
            <tr>
                <td>club T-shirt</td>
                <td>Leadership</td>
                <td>2019-04-10</td>
                <td>$ 300.00</td>
                
            </tr>
            <tr>
                <td>Mineral water and food package</td>
                <td>Pencarian</td>
                <td>2019-03-08</td>
                <td>$ 100.00</td>
            </tr>
            <tr>
                <td>goodies and certificate paper</td>
                <td>Electrorace fkekk</td>
                <td>2019-02-10</td>
                <td>$ 50.00</td>
            </tr>
            <tr>
                <td>food and drink for AJK</td>
                <td>Komplot</td>
                <td>2019-01-10</td>
                <td>$ 100.00</td>
                
            </tr>
            <tr>
                <td>T-Shirt</td>
                <td>Leadership</td>
                <td>2018-09-08</td>
                <td>$ 34.00 </td>
            </tr>
            <tr>
                <td>Drink and Food</td>
                <td>Electrorace fkekk</td>
                <td>2018-05-24</td>
                <td>$ 300.00</td>
            </tr>
            <tr>
                <td>sponsor</td>
                <td>Komplot</td>
                <td>2019-05-07</td>
                <td>$ 900.00</td>
            </tr>
            <tr>Certificate Paper</td>
                <td>Leadership</td>
                <td>2018-02-04</td>
                <td>$ 34.00</td>
            </tr>
            <tr>
                <td>Booking Tent</td>
                <td>Fkekk Fest</td>
                <td>2017-10-02</td>
                <td>$ 100</td>
            </tr>
            <tr>
                <td>Certificate Paper</td>
                <td>Fkekk Fest</td>
                <td>2017-10-03</td>
                <td>$ 50</td>
            </tr>
            <tr>
                <td>Food</td>
                <td>Electrorace Fkekk</td>
                <td>2017-11-03</td>
                <td>$ 200</td>
           
            </tr>
            <tr>
                <td>T-shirt</td>
                <td>Electrorace Fkekk</td>
                <td>2017-12-14</td>
                <td>$ 200</td>
           
            </tr>
            <tr>
                <td>Certificate Paper</td>
                <td>c++ Workshop</td>
                <td>2018-07-02</td>
                <td>$ 25</td>
            </tr>
            
        </tbody>
        <tfoot>
            <tr>
                <th colspan="3" style="text-align:right">Total:</th>
                <th></th>
            </tr>
        </tfoot>
    </table>
                                </div>
                            </div>
                            <!-- END EXAMPLE TABLE PORTLET-->
                        </div>
                    </div>
                  
                </div>
                <!-- END CONTENT BODY -->
            </div>
            <!-- END CONTENT -->
              <div id="large" class="modal fade bs-modal-lg" tabindex="-1" data-backdrop="static" data-keyboard="false">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                                                    <h4 class="modal-title">Add New</h4>
                                                </div>
                                                <div class="modal-body">
                                                   <form role="form" method="POST" action="add_income.php" enctype="multipart/form-data">
                                                                                 
                                    <div class="form-group">
            <div class="fileinput fileinput-new" data-provides="fileinput">
                   
                            
                                            </div>
                                          <label>Income Name</label>
                                          <input type="text" name="income" class="form-control tooltips" data-trigger="hover" data-toggle="tooltip" title="" placeholder="Place your title here!" data-original-title="Input Title here" required>
                                          
                                          <label>Activity ID</label>
                                          <select class="form-control select2" name="activity_Id" onChange="showDetails(this.value)">
                                          <option></option>
                                      
                                          <?php
                                           include "../../functions/connect.php";
                                           $cs = mysql_query("SELECT * from activity");

                                           if($cs==true){
                                           while($row=mysql_fetch_assoc($cs)){
                                           extract($row);
                                           echo '<option value='.$activity_Id.'>'.$activity_name.'</option>';
                                           }
                                           }

                                           ?>
                                           </select>
                                           
                                   
                                               <label>Income Value</label>
                                          <input type="number" name="tvalue" class="form-control tooltips" data-trigger="hover" data-toggle="tooltip" title="" placeholder="Place your title here!" data-original-title="Input Value here" required>
                                          
                                          <label>Date of Income</label>
                                          <input type="date" name="date" class="form-control tooltips" data-trigger="hover" data-toggle="tooltip" title="" placeholder="Place your title here!" data-original-title="Input Date here" required>
                                          
                                          

                                        

                                                <div class="modal-footer">
                                                    <button type="button" data-dismiss="modal" class="btn dark btn-outline">Cancel</button>
                                                         <button type="submit" class="btn btn-primary">Submit</button>
                                                </div>
                                                  </div>

                                                </form>
                                            </div>
                                        </div>
                                    </div>



             
           <?php footertemplate();?>

            
</body>