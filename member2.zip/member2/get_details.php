
	<?php
  include "../functions/connect.php";
$q = intval($_GET['q']);
$sql = "select * from tbl_sub_category as sub join tbl_main_category as main on sub.cat_Id=main.cat_Id where main.cat_Id='".$q."'";
$result = mysql_query($sql);
while($row = mysql_fetch_array($result)) {

    extract($row);
$sub_Id;
?>

<table class="table table-striped table-bordered table-hover table-checkable order-column">
	<tr>
			<td style="width:20px;">
				<input type="checkbox" name="sub_Id" value="<?php echo $sub_Id;?>" onchange="showMenu(this.value)">
			</td>
			<td>
				    		<?php echo $sub_category;?>		
			</td>	
	</tr>
</table>
	

<?php
    }
?>

